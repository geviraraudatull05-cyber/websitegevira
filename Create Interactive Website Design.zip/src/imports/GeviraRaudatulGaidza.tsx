import svgPaths from "./svg-g7jwak5mum";
import imgDownloads5 from "figma:asset/8904e9bd4c869812752fc694644cf351aa1d65da.png";
import imgStar4 from "figma:asset/1374530e4b9bd61ddb1f4c2b7931ee05e8e62d29.png";
import imgLogoOfTheMinistryOfTransportationOfTheRepublicOfIndonesiaSvg3 from "figma:asset/3bfa393da5c7e75718c0c7d3237222e5508c2b15.png";
import imgSearch from "figma:asset/1255b58b1dcde0e7c3b8b088bb125465c7629532.png";
import imgDogHouse from "figma:asset/b96cbb0b7b2a3978a52a4b574435233365fb67c9.png";
import img1 from "figma:asset/a9e8e2fd6128b8801b8640d191946da8f61fdc23.png";
import imgChevronLeft from "figma:asset/a36f5273f4f5e18b717995845467c06f9879ed33.png";
import imgChevronRight from "figma:asset/0ff3b363044e5d897dd2762b24aa56c79433a9d5.png";
import imgFacebook11 from "figma:asset/dd126e7d24b6fd33ca4991f1b8a9bd87c6de70d6.png";
import imgTwitter1 from "figma:asset/1f56cfd696185ea0091a7076c94f7c7bdb79a31b.png";
import imgInstagram1 from "figma:asset/b02061ce958aac22de14352bc6075e23a8446393.png";
import imgYoutube1 from "figma:asset/42d01f6e3a4b5bdb3e68aabec11dc45c5bd80876.png";
import imgEmail1 from "figma:asset/4791a4dae07c574f5ca0a5ec0aaf15664e95f9e2.png";
import imgPlaceMarker from "figma:asset/ade4c520b776a26145d2788f2d797c53d01a16fb.png";
import imgNext1 from "figma:asset/6d652c777fa83a3616d90bd1f2ab0f65fcc373c4.png";
import imgCalendar1 from "figma:asset/d0e62a390b8cd8d89090fa032936ef572244442a.png";
import imgCalendar21 from "figma:asset/fc2d8083d145ea8aa3f8a2ddced2d9ccf8284498.png";
import imgClock11 from "figma:asset/2af721beddc14fbdbf3966340ed79ee272b1f630.png";
import img26 from "figma:asset/9d7a5d137344a5205adc251e6dcd17fe5df700ad.png";
import img27 from "figma:asset/82e270885614ec80a152af2b144e891504f873c8.png";
import img28 from "figma:asset/6f219dfe04ae5e3eb96bc1e56fe41bc18945c451.png";
import img29 from "figma:asset/7fb17122d994ad64f47fdcfbf4e25dee2a842d3c.png";
import img31 from "figma:asset/829ac163144a4af573c02f03eb286f567595ce5d.png";
import imgRise1 from "figma:asset/3681bad6a81cf0f1ef595a1e0e476e35b3216d75.png";
import imgMotorbike1 from "figma:asset/a61cfa48f612af733e61e8dc5c407f9017968253.png";
import imgArrow1 from "figma:asset/64c52d1a0f9d8a56ee35bd7cb66fb1a66846e8ef.png";
import imgGoogleDocs1 from "figma:asset/af94b06127c0a50bcef9e1fcf5358c810b593a9a.png";
import imgBadge1 from "figma:asset/4083e2de094e2ce8b91c7214a2cd7096083ad44a.png";
import imgCheckmark1 from "figma:asset/ece0d9d9d2b002fcbc8b36473a533cb6dd9061f8.png";
import imgGoogleDocs21 from "figma:asset/399e1a46362916ac859ee4d863a706f897f17659.png";
import imgMessage1 from "figma:asset/31bd99ac360966356d9145a6b8087d6f079d146c.png";
import imgLaw1 from "figma:asset/899644a22839225323bb9d7ee81c479108be16fd.png";
import imgCityHall1 from "figma:asset/b10cdc1f2a74a931cfd8b12b1eb91234ef889b37.png";
import imgSkyline11 from "figma:asset/a8368a28b6620b1d7786f406c7cc18aff98b3d52.png";
import imgBus1 from "figma:asset/86871af62f130eea472547664a5b5be5b0439b0c.png";
import imgCamera1 from "figma:asset/a4ef37c1b25d2f6f89e6a26a37be85ab06c4e3a0.png";
import imgCheckmark11 from "figma:asset/7ee0ed1241f9b3b1c5f144abe64d262458097327.png";
import imgImage4 from "figma:asset/b527c12a6ee08a431effdf8117279573c12afb54.png";
import imgLogoSb11 from "figma:asset/a1009a8ab9c9c498c74c7fcf5faf315ade7abe59.png";
import imgSuv from "figma:asset/155434e0f6ee2ae63b75b40b8150e0728dcb9143.png";
import imgShare1 from "figma:asset/91c5b2af5f5ea9436b4435728a12bbb5ee9015fb.png";
import imgStar11 from "figma:asset/e257bc8271d35f6c81a564dbbe5e94308cf519c4.png";
import imgCheckmark21 from "figma:asset/59afd9055168ac1e44cb4ea27e307afdb051aca1.png";
import imgCheckmark31 from "figma:asset/536647fe624d6c7e50b1b956a98babae7763ba76.png";
import img101 from "figma:asset/372fd53facb1ff0c64a329ea513a21b1486ed901.png";
import imgPhone from "figma:asset/661204f24e7ce16a8a5113d85f60765a7a863c18.png";
import imgGmailLogo from "figma:asset/1014821925048665bcbb86bf6d129cd0ee00cc16.png";

function Group() {
  return (
    <div className="absolute contents left-[93px] top-[5756px]">
      <div className="absolute bg-[#f2f4f7] h-[269px] left-[93px] rounded-[30px] shadow-[-3px_6px_25px_0px_rgba(0,0,0,0.4)] top-[5756px] w-[417px]" />
      <div className="absolute bg-[#68aff6] left-[121px] rounded-[20px] size-[90px] top-[5782px]" />
      <div className="absolute bg-[#1d2939] h-[53px] left-[129px] rounded-[30px] top-[5945px] w-[346px]" />
      <div className="absolute flex flex-col font-['Inter:Semi_Bold',sans-serif] font-semibold h-[57px] justify-center leading-[0] left-[223px] not-italic text-[20px] text-white top-[5971.5px] translate-y-[-50%] w-[198px]">
        <p className="leading-[20px]">Download Aplikasi</p>
      </div>
      <div className="absolute left-[186px] size-[25px] top-[5959px]" data-name="downloads 5">
        <img alt="" className="absolute inset-0 max-w-none object-50%-50% object-cover pointer-events-none size-full" src={imgDownloads5} />
      </div>
      <div className="absolute flex flex-col font-['Inter:Semi_Bold',sans-serif] font-semibold h-[44px] justify-center leading-[0] left-[220px] not-italic text-[20px] text-black top-[5804px] translate-y-[-50%] w-[308px]">
        <p className="leading-[20px]">E-Dishub Kota Surabaya</p>
      </div>
      <div className="absolute left-[223px] size-[16px] top-[5826px]" data-name="star 4">
        <img alt="" className="absolute inset-0 max-w-none object-50%-50% object-cover pointer-events-none size-full" src={imgStar4} />
      </div>
      <div className="absolute flex flex-col font-['Inter:Semi_Bold',sans-serif] font-semibold h-[22px] justify-center leading-[0] left-[244px] not-italic text-[#fec84b] text-[16px] top-[5835px] translate-y-[-50%] w-[27px]">
        <p className="leading-[16px]">4.6</p>
      </div>
      <div className="absolute left-[285px] size-[5px] top-[5831px]">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 5 5">
          <circle cx="2.5" cy="2.5" fill="var(--fill-0, #475467)" id="Ellipse 12" r="2.5" />
        </svg>
      </div>
      <div className="absolute flex flex-col font-['Inter:Semi_Bold',sans-serif] font-semibold h-[12px] justify-center leading-[0] left-[295px] not-italic text-[#475467] text-[16px] top-[5834px] translate-y-[-50%] w-[51px]">
        <p className="leading-[16px]">30K+</p>
      </div>
      <div className="absolute flex flex-col font-['Inter:Medium',sans-serif] font-medium h-[42px] justify-center leading-[20px] left-[122px] not-italic text-[#475467] text-[20px] top-[5916px] translate-y-[-50%] w-[399px]">
        <p className="mb-0">Layanan digital Dinas Perhubungan</p>
        <p>&nbsp;</p>
      </div>
      <div className="absolute h-[49px] left-[145px] top-[5806px] w-[42px]" data-name="Logo_of_the_Ministry_of_Transportation_of_the_Republic_of_Indonesia.svg 3">
        <img alt="" className="absolute inset-0 max-w-none object-50%-50% object-cover pointer-events-none size-full" src={imgLogoOfTheMinistryOfTransportationOfTheRepublicOfIndonesiaSvg3} />
      </div>
    </div>
  );
}

export default function GeviraRaudatulGaidza() {
  return (
    <div className="bg-white relative size-full" data-name="GEVIRA RAUDATUL GAIDZA">
      <div className="absolute bg-[#f2f4f7] h-[6900px] left-0 top-[1133px] w-[2071px]" />
      <div className="absolute bg-gradient-to-l from-[#457fc9] h-[94px] left-0 to-[#1e5ba8] top-[159px] w-[2080px]" />
      <div className="absolute bg-[#d0d5dd] h-[1480px] left-0 top-[3673px] w-[2071px]" />
      <div className="absolute bg-[#d0d5dd] h-[676px] left-0 top-[6169px] w-[2071px]" />
      <div className="absolute h-0 left-[98px] top-[6248px] w-[116px]">
        <div className="absolute bottom-0 left-0 right-0 top-[-8px]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 116 8">
            <line id="Line 31" stroke="var(--stroke-0, #F79009)" strokeLinecap="round" strokeWidth="8" x1="4" x2="112" y1="4" y2="4" />
          </svg>
        </div>
      </div>
      <div className="absolute h-0 left-[98px] top-[6248px] w-[116px]">
        <div className="absolute bottom-0 left-0 right-0 top-[-8px]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 116 8">
            <line id="Line 31" stroke="var(--stroke-0, #F79009)" strokeLinecap="round" strokeWidth="8" x1="4" x2="112" y1="4" y2="4" />
          </svg>
        </div>
      </div>
      <div className="absolute flex flex-col font-['Inter:Bold',sans-serif] font-bold h-[87px] justify-center leading-[0] left-[94px] not-italic text-[#2c5e8f] text-[48px] top-[6302.5px] translate-y-[-50%] w-[469px]">
        <p className="leading-[60px]">PENYEDIA TIKET</p>
      </div>
      <div className="absolute flex flex-col font-['Inter:Medium',sans-serif] font-medium h-[85px] justify-center leading-[0] left-[96px] not-italic text-[#475467] text-[20px] top-[6362.5px] translate-y-[-50%] w-[839px]">
        <p className="leading-[20px]">Partner Resmi Layanan Transportasi</p>
      </div>
      <div className="absolute h-[87px] left-[48px] top-[60px] w-[75px]" data-name="Logo_of_the_Ministry_of_Transportation_of_the_Republic_of_Indonesia.svg 1">
        <img alt="" className="absolute inset-0 max-w-none object-50%-50% object-cover pointer-events-none size-full" src={imgLogoOfTheMinistryOfTransportationOfTheRepublicOfIndonesiaSvg3} />
      </div>
      <div className="absolute flex h-[65px] items-center justify-center left-[144px] top-[68px] w-0" style={{ "--transform-inner-width": "65", "--transform-inner-height": "0" } as React.CSSProperties}>
        <div className="flex-none rotate-[90deg]">
          <div className="h-0 relative w-[65px]">
            <div className="absolute bottom-0 left-0 right-0 top-[-1px]">
              <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 65 1">
                <line id="Line 4" stroke="var(--stroke-0, #EAECF0)" x2="65" y1="0.5" y2="0.5" />
              </svg>
            </div>
          </div>
        </div>
      </div>
      <div className="absolute flex h-[35px] items-center justify-center left-[144px] top-[71px] w-0" style={{ "--transform-inner-width": "35", "--transform-inner-height": "0" } as React.CSSProperties}>
        <div className="flex-none rotate-[90deg]">
          <div className="h-0 relative w-[35px]">
            <div className="absolute bottom-0 left-0 right-0 top-[-1px]">
              <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 35 1">
                <line id="Line 3" stroke="var(--stroke-0, black)" x2="35" y1="0.5" y2="0.5" />
              </svg>
            </div>
          </div>
        </div>
      </div>
      <div className="absolute flex flex-col font-['Inter:Bold',sans-serif] font-bold justify-center leading-[0] left-[170px] not-italic text-[#2c5e8f] text-[48px] text-nowrap top-[89px] translate-y-[-50%]">
        <p className="leading-[60px] whitespace-pre">DISHUB</p>
      </div>
      <div className="absolute flex flex-col font-['Inter:Bold',sans-serif] font-bold justify-center leading-[0] left-[170px] not-italic text-[#475467] text-[20px] text-nowrap top-[121px] translate-y-[-50%]">
        <p className="leading-[20px] whitespace-pre">PEMERINTAH KOTA SURABAYA</p>
      </div>
      <div className="absolute flex flex-col font-['Inter:Bold',sans-serif] font-bold h-[30px] justify-center leading-[0] left-[156px] not-italic text-[24px] text-white top-[206px] translate-y-[-50%] w-[87px]">
        <p className="leading-[24px]">BERITA</p>
      </div>
      <div className="absolute flex flex-col font-['Inter:Bold',sans-serif] font-bold h-[30px] justify-center leading-[0] left-[279px] not-italic text-[24px] text-white top-[206px] translate-y-[-50%] w-[165px]">
        <p className="leading-[24px]">E-ANGKUTAN</p>
      </div>
      <div className="absolute flex flex-col font-['Inter:Bold',sans-serif] font-bold h-[30px] justify-center leading-[0] left-[476px] not-italic text-[24px] text-white top-[206px] translate-y-[-50%] w-[165px]">
        <p className="leading-[24px]">E-DALOPS</p>
      </div>
      <div className="absolute flex flex-col font-['Inter:Bold',sans-serif] font-bold h-[30px] justify-center leading-[0] left-[636px] not-italic text-[24px] text-white top-[206px] translate-y-[-50%] w-[165px]">
        <p className="leading-[24px]">E-LALIN</p>
      </div>
      <div className="absolute flex flex-col font-['Inter:Bold',sans-serif] font-bold h-[30px] justify-center leading-[0] left-[769px] not-italic text-[24px] text-white top-[206px] translate-y-[-50%] w-[165px]">
        <p className="leading-[24px]">E-PARKIR</p>
      </div>
      <div className="absolute flex flex-col font-['Inter:Bold',sans-serif] font-bold h-[30px] justify-center leading-[0] left-[918px] not-italic text-[24px] text-white top-[205px] translate-y-[-50%] w-[165px]">
        <p className="leading-[24px]">E-PKB</p>
      </div>
      <div className="absolute flex flex-col font-['Inter:Bold',sans-serif] font-bold h-[30px] justify-center leading-[0] left-[1034px] not-italic text-[24px] text-white top-[206px] translate-y-[-50%] w-[165px]">
        <p className="leading-[24px]">E-SARPRAS</p>
      </div>
      <div className="absolute flex flex-col font-['Inter:Bold',sans-serif] font-bold h-[30px] justify-center leading-[0] left-[1200px] not-italic text-[24px] text-white top-[206px] translate-y-[-50%] w-[165px]">
        <p className="leading-[24px]">E-TERMINAL</p>
      </div>
      <div className="absolute flex flex-col font-['Inter:Bold',sans-serif] font-bold h-[30px] justify-center leading-[0] left-[1382px] not-italic text-[24px] text-white top-[206px] translate-y-[-50%] w-[210px]">
        <p className="leading-[24px]">PERWALI DISHUB</p>
      </div>
      <div className="absolute flex flex-col font-['Inter:Bold',sans-serif] font-bold justify-center leading-[0] left-[1825px] not-italic text-[#98a2b3] text-[24px] text-nowrap top-[99px] translate-y-[-50%]">
        <p className="leading-[24px] whitespace-pre">Profil</p>
      </div>
      <div className="absolute flex flex-col font-['Inter:Bold',sans-serif] font-bold justify-center leading-[0] left-[1957px] not-italic text-[#98a2b3] text-[24px] text-nowrap top-[98px] translate-y-[-50%]">
        <p className="leading-[24px] whitespace-pre">Karir</p>
      </div>
      <div className="absolute flex h-[26px] items-center justify-center left-[1916px] top-[88px] w-0" style={{ "--transform-inner-width": "26", "--transform-inner-height": "0" } as React.CSSProperties}>
        <div className="flex-none rotate-[90deg]">
          <div className="h-0 relative w-[26px]">
            <div className="absolute bottom-0 left-0 right-0 top-[-2px]">
              <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 26 2">
                <line id="Line 5" stroke="var(--stroke-0, #EAECF0)" strokeWidth="2" x2="26" y1="1" y2="1" />
              </svg>
            </div>
          </div>
        </div>
      </div>
      <div className="absolute bg-[#eaecf0] h-[58px] left-[1448px] rounded-[40px] top-[73px] w-[312px]" />
      <div className="absolute flex flex-col font-['Inter:Bold',sans-serif] font-bold justify-center leading-[0] left-[1505px] not-italic text-[#98a2b3] text-[24px] text-nowrap top-[99px] translate-y-[-50%]">
        <p className="leading-[24px] whitespace-pre">Cari Layanan...</p>
      </div>
      <div className="absolute h-[45px] left-[1460px] top-[79px] w-[25px]" data-name="Search">
        <img alt="" className="absolute inset-0 max-w-none object-50%-50% object-contain opacity-50 pointer-events-none size-full" src={imgSearch} />
      </div>
      <div className="absolute h-[53px] left-[65px] top-[179px] w-[42px]" data-name="Dog House">
        <img alt="" className="absolute inset-0 max-w-none object-50%-50% object-contain pointer-events-none size-full" src={imgDogHouse} />
      </div>
      <div className="absolute flex h-[39px] items-center justify-center left-[137px] top-[186px] w-0" style={{ "--transform-inner-width": "39", "--transform-inner-height": "0" } as React.CSSProperties}>
        <div className="flex-none rotate-[90deg]">
          <div className="h-0 relative w-[39px]">
            <div className="absolute bottom-0 left-0 right-0 top-[-2px]" style={{ "--stroke-0": "rgba(255, 255, 255, 1)" } as React.CSSProperties}>
              <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 39 2">
                <line id="Line 6" stroke="var(--stroke-0, white)" strokeOpacity="0.2" strokeWidth="2" x2="39" y1="1" y2="1" />
              </svg>
            </div>
          </div>
        </div>
      </div>
      <div className="absolute flex h-[39px] items-center justify-center left-[260px] top-[186px] w-0" style={{ "--transform-inner-width": "39", "--transform-inner-height": "0" } as React.CSSProperties}>
        <div className="flex-none rotate-[90deg]">
          <div className="h-0 relative w-[39px]">
            <div className="absolute bottom-0 left-0 right-0 top-[-2px]" style={{ "--stroke-0": "rgba(255, 255, 255, 1)" } as React.CSSProperties}>
              <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 39 2">
                <line id="Line 6" stroke="var(--stroke-0, white)" strokeOpacity="0.2" strokeWidth="2" x2="39" y1="1" y2="1" />
              </svg>
            </div>
          </div>
        </div>
      </div>
      <div className="absolute flex h-[39px] items-center justify-center left-[454px] top-[186px] w-0" style={{ "--transform-inner-width": "39", "--transform-inner-height": "0" } as React.CSSProperties}>
        <div className="flex-none rotate-[90deg]">
          <div className="h-0 relative w-[39px]">
            <div className="absolute bottom-0 left-0 right-0 top-[-2px]" style={{ "--stroke-0": "rgba(255, 255, 255, 1)" } as React.CSSProperties}>
              <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 39 2">
                <line id="Line 6" stroke="var(--stroke-0, white)" strokeOpacity="0.2" strokeWidth="2" x2="39" y1="1" y2="1" />
              </svg>
            </div>
          </div>
        </div>
      </div>
      <div className="absolute flex h-[39px] items-center justify-center left-[614px] top-[186px] w-0" style={{ "--transform-inner-width": "39", "--transform-inner-height": "0" } as React.CSSProperties}>
        <div className="flex-none rotate-[90deg]">
          <div className="h-0 relative w-[39px]">
            <div className="absolute bottom-0 left-0 right-0 top-[-2px]" style={{ "--stroke-0": "rgba(255, 255, 255, 1)" } as React.CSSProperties}>
              <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 39 2">
                <line id="Line 6" stroke="var(--stroke-0, white)" strokeOpacity="0.2" strokeWidth="2" x2="39" y1="1" y2="1" />
              </svg>
            </div>
          </div>
        </div>
      </div>
      <div className="absolute flex h-[39px] items-center justify-center left-[748px] top-[186px] w-0" style={{ "--transform-inner-width": "39", "--transform-inner-height": "0" } as React.CSSProperties}>
        <div className="flex-none rotate-[90deg]">
          <div className="h-0 relative w-[39px]">
            <div className="absolute bottom-0 left-0 right-0 top-[-2px]" style={{ "--stroke-0": "rgba(255, 255, 255, 1)" } as React.CSSProperties}>
              <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 39 2">
                <line id="Line 6" stroke="var(--stroke-0, white)" strokeOpacity="0.2" strokeWidth="2" x2="39" y1="1" y2="1" />
              </svg>
            </div>
          </div>
        </div>
      </div>
      <div className="absolute flex h-[39px] items-center justify-center left-[895px] top-[186px] w-0" style={{ "--transform-inner-width": "39", "--transform-inner-height": "0" } as React.CSSProperties}>
        <div className="flex-none rotate-[90deg]">
          <div className="h-0 relative w-[39px]">
            <div className="absolute bottom-0 left-0 right-0 top-[-2px]" style={{ "--stroke-0": "rgba(255, 255, 255, 1)" } as React.CSSProperties}>
              <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 39 2">
                <line id="Line 6" stroke="var(--stroke-0, white)" strokeOpacity="0.2" strokeWidth="2" x2="39" y1="1" y2="1" />
              </svg>
            </div>
          </div>
        </div>
      </div>
      <div className="absolute flex h-[39px] items-center justify-center left-[1008px] top-[186px] w-0" style={{ "--transform-inner-width": "39", "--transform-inner-height": "0" } as React.CSSProperties}>
        <div className="flex-none rotate-[90deg]">
          <div className="h-0 relative w-[39px]">
            <div className="absolute bottom-0 left-0 right-0 top-[-2px]" style={{ "--stroke-0": "rgba(255, 255, 255, 1)" } as React.CSSProperties}>
              <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 39 2">
                <line id="Line 6" stroke="var(--stroke-0, white)" strokeOpacity="0.2" strokeWidth="2" x2="39" y1="1" y2="1" />
              </svg>
            </div>
          </div>
        </div>
      </div>
      <div className="absolute flex h-[39px] items-center justify-center left-[1181px] top-[186px] w-0" style={{ "--transform-inner-width": "39", "--transform-inner-height": "0" } as React.CSSProperties}>
        <div className="flex-none rotate-[90deg]">
          <div className="h-0 relative w-[39px]">
            <div className="absolute bottom-0 left-0 right-0 top-[-2px]" style={{ "--stroke-0": "rgba(255, 255, 255, 1)" } as React.CSSProperties}>
              <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 39 2">
                <line id="Line 6" stroke="var(--stroke-0, white)" strokeOpacity="0.2" strokeWidth="2" x2="39" y1="1" y2="1" />
              </svg>
            </div>
          </div>
        </div>
      </div>
      <div className="absolute flex h-[39px] items-center justify-center left-[1360px] top-[186px] w-0" style={{ "--transform-inner-width": "39", "--transform-inner-height": "0" } as React.CSSProperties}>
        <div className="flex-none rotate-[90deg]">
          <div className="h-0 relative w-[39px]">
            <div className="absolute bottom-0 left-0 right-0 top-[-2px]" style={{ "--stroke-0": "rgba(255, 255, 255, 1)" } as React.CSSProperties}>
              <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 39 2">
                <line id="Line 6" stroke="var(--stroke-0, white)" strokeOpacity="0.2" strokeWidth="2" x2="39" y1="1" y2="1" />
              </svg>
            </div>
          </div>
        </div>
      </div>
      <div className="absolute h-[882px] left-0 top-[248px] w-[2078px]" data-name="1">
        <div className="absolute inset-0 overflow-hidden pointer-events-none">
          <img alt="" className="absolute h-[132.65%] left-[-0.02%] max-w-none top-[-19.84%] w-[100.03%]" src={img1} />
        </div>
      </div>
      <div className="absolute bg-[rgba(47,132,243,0.45)] h-[884px] left-0 top-[248px] w-[2071px]" />
      <div className="absolute flex flex-col font-['Inter:Bold',sans-serif] font-bold h-[147px] justify-center leading-[0] left-[84px] not-italic text-[60px] text-white top-[637.5px] translate-y-[-50%] w-[663px]">
        <p className="leading-[72px]">TAMAN SUROBOYO</p>
      </div>
      <div className="absolute flex flex-col font-['Inter:Semi_Bold',sans-serif] font-semibold h-[169px] justify-center leading-[0] left-[84px] not-italic text-[36px] text-white top-[723.5px] translate-y-[-50%] w-[619px]">
        <p className="leading-[44px]">Dinas Perhubungan kota Surabaya</p>
      </div>
      <div className="absolute h-0 left-[84px] top-[554px] w-[116px]">
        <div className="absolute bottom-0 left-0 right-0 top-[-8px]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 116 8">
            <line id="Line 31" stroke="var(--stroke-0, #F79009)" strokeLinecap="round" strokeWidth="8" x1="4" x2="112" y1="4" y2="4" />
          </svg>
        </div>
      </div>
      <div className="absolute h-0 left-[94px] top-[1191px] w-[116px]">
        <div className="absolute bottom-0 left-0 right-0 top-[-8px]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 116 8">
            <line id="Line 31" stroke="var(--stroke-0, #F79009)" strokeLinecap="round" strokeWidth="8" x1="4" x2="112" y1="4" y2="4" />
          </svg>
        </div>
      </div>
      <div className="absolute h-0 left-[982px] top-[1463px] w-[116px]">
        <div className="absolute bottom-0 left-0 right-0 top-[-8px]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 116 8">
            <line id="Line 31" stroke="var(--stroke-0, #F79009)" strokeLinecap="round" strokeWidth="8" x1="4" x2="112" y1="4" y2="4" />
          </svg>
        </div>
      </div>
      <div className="absolute h-0 left-[949px] top-[1103px] w-[65px]">
        <div className="absolute bottom-0 left-0 right-0 top-[-15px]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 65 15">
            <line id="Line 17" stroke="var(--stroke-0, #F79009)" strokeLinecap="round" strokeWidth="15" x1="7.5" x2="57.5" y1="7.5" y2="7.5" />
          </svg>
        </div>
      </div>
      <div className="absolute h-[15px] left-[1062px] top-[1088px] w-[17px]">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 17 15">
          <ellipse cx="8.5" cy="7.5" fill="var(--fill-0, #D0D5DD)" id="Ellipse 2" rx="8.5" ry="7.5" />
        </svg>
      </div>
      <div className="absolute h-[15px] left-[1030px] top-[1088px] w-[17px]">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 17 15">
          <ellipse cx="8.5" cy="7.5" fill="var(--fill-0, #D0D5DD)" id="Ellipse 2" rx="8.5" ry="7.5" />
        </svg>
      </div>
      <div className="absolute h-[56px] left-[13px] top-[662px] w-[55px]">
        <div className="absolute inset-0" style={{ "--fill-0": "rgba(217, 217, 217, 1)" } as React.CSSProperties}>
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 55 56">
            <ellipse cx="27.5" cy="28" fill="var(--fill-0, #D9D9D9)" fillOpacity="0.5" id="Ellipse 4" rx="27.5" ry="28" />
          </svg>
        </div>
      </div>
      <div className="absolute h-[58px] left-[26px] top-[661px] w-[30px]" data-name="Chevron Left">
        <img alt="" className="absolute inset-0 max-w-none object-50%-50% object-contain pointer-events-none size-full" src={imgChevronLeft} />
      </div>
      <div className="absolute h-[56px] left-[2009px] top-[661px] w-[55px]">
        <div className="absolute inset-0" style={{ "--fill-0": "rgba(217, 217, 217, 1)" } as React.CSSProperties}>
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 55 56">
            <ellipse cx="27.5" cy="28" fill="var(--fill-0, #D9D9D9)" fillOpacity="0.5" id="Ellipse 4" rx="27.5" ry="28" />
          </svg>
        </div>
      </div>
      <div className="absolute h-[44px] left-[2022px] top-[667px] w-[30px]" data-name="Chevron Right">
        <img alt="" className="absolute inset-0 max-w-none object-50%-50% object-contain pointer-events-none size-full" src={imgChevronRight} />
      </div>
      <div className="absolute bg-gradient-to-l from-[#457fc9] h-[44px] left-0 to-[#1e5ba8] top-0 w-[2071px]" />
      <div className="absolute flex flex-col font-['Inter:Semi_Bold',sans-serif] font-semibold h-[30px] justify-center leading-[0] left-[110px] not-italic text-[20px] text-white top-[22px] translate-y-[-50%] w-[210px]">
        <p className="leading-[20px]">Surabaya, Indonesia</p>
      </div>
      <div className="absolute flex flex-col font-['Inter:Semi_Bold',sans-serif] font-semibold h-[30px] justify-center leading-[0] left-[404px] not-italic text-[20px] text-white top-[22px] translate-y-[-50%] w-[210px]">
        <p className="leading-[20px]">23 November 2025</p>
      </div>
      <div className="absolute h-[513px] left-[1475px] top-[76px] w-[512px]" data-name="image 2" />
      <div className="absolute left-[1760px] size-[28px] top-[8px]" data-name="facebook (1) 1">
        <img alt="" className="absolute inset-0 max-w-none object-50%-50% object-cover pointer-events-none size-full" src={imgFacebook11} />
      </div>
      <div className="absolute left-[1805px] size-[28px] top-[8px]" data-name="twitter 1">
        <img alt="" className="absolute inset-0 max-w-none object-50%-50% object-cover pointer-events-none size-full" src={imgTwitter1} />
      </div>
      <div className="absolute left-[1863px] size-[26px] top-[10px]" data-name="instagram 1">
        <img alt="" className="absolute inset-0 max-w-none object-50%-50% object-cover pointer-events-none size-full" src={imgInstagram1} />
      </div>
      <div className="absolute left-[1919px] size-[33px] top-[11px]" data-name="youtube 1">
        <img alt="" className="absolute inset-0 max-w-none object-50%-50% object-cover pointer-events-none size-full" src={imgYoutube1} />
      </div>
      <div className="absolute left-[1980px] size-[32px] top-[7px]" data-name="email 1">
        <img alt="" className="absolute inset-0 max-w-none object-50%-50% object-cover pointer-events-none size-full" src={imgEmail1} />
      </div>
      <div className="absolute bg-[#f79009] h-[79px] left-[84px] rounded-[20px] top-[796px] w-[260px]" data-name="Rectangle" />
      <div className="absolute flex flex-col font-['Inter:Semi_Bold',sans-serif] font-semibold h-[54px] justify-center leading-[0] left-[214.5px] not-italic text-[24px] text-center text-white top-[836px] translate-x-[-50%] translate-y-[-50%] w-[259px]">
        <p className="leading-[24px]">Jelajahi layanan</p>
      </div>
      <div className="absolute h-[31px] left-[69px] top-[6px] w-[30px]" data-name="Place Marker">
        <img alt="" className="absolute inset-0 max-w-none object-50%-50% object-contain pointer-events-none size-full" src={imgPlaceMarker} />
      </div>
      <div className="absolute flex flex-col font-['Inter:Bold',sans-serif] font-bold h-[87px] justify-center leading-[0] left-[90px] not-italic text-[#2c5e8f] text-[48px] top-[1245.5px] translate-y-[-50%] w-[469px]">
        <p className="leading-[60px]">BERITA TERBARU</p>
      </div>
      <div className="absolute flex flex-col font-['Inter:Medium',sans-serif] font-medium h-[85px] justify-center leading-[0] left-[92px] not-italic text-[#475467] text-[24px] top-[1305.5px] translate-y-[-50%] w-[839px]">
        <p className="leading-[24px]">Informasi dan Update Terkini</p>
      </div>
      <div className="absolute h-0 left-[94px] top-[2763px] w-[116px]">
        <div className="absolute bottom-0 left-0 right-0 top-[-8px]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 116 8">
            <line id="Line 31" stroke="var(--stroke-0, #F79009)" strokeLinecap="round" strokeWidth="8" x1="4" x2="112" y1="4" y2="4" />
          </svg>
        </div>
      </div>
      <div className="absolute h-0 left-[94px] top-[2763px] w-[116px]">
        <div className="absolute bottom-0 left-0 right-0 top-[-8px]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 116 8">
            <line id="Line 31" stroke="var(--stroke-0, #F79009)" strokeLinecap="round" strokeWidth="8" x1="4" x2="112" y1="4" y2="4" />
          </svg>
        </div>
      </div>
      <div className="absolute flex flex-col font-['Inter:Bold',sans-serif] font-bold h-[87px] justify-center leading-[0] left-[90px] not-italic text-[#2c5e8f] text-[60px] top-[2817.5px] translate-y-[-50%] w-[469px]">
        <p className="leading-[72px]">LOT PTK</p>
      </div>
      <div className="absolute flex flex-col font-['Inter:Medium',sans-serif] font-medium h-[85px] justify-center leading-[0] left-[92px] not-italic text-[#475467] text-[20px] top-[2877.5px] translate-y-[-50%] w-[839px]">
        <p className="leading-[20px]">Status Ketersediaan Parkir Real-Time</p>
      </div>
      <div className="absolute flex flex-col font-['Inter:Bold',sans-serif] font-bold h-[88px] justify-center leading-[0] left-[1731px] not-italic text-[#f79009] text-[30px] top-[1246px] translate-y-[-50%] w-[211px]">
        <p className="leading-[30px]">{`Lihat Semua `}</p>
      </div>
      <div className="absolute left-[1942px] size-[44px] top-[1224px]" data-name="next 1">
        <img alt="" className="absolute inset-0 max-w-none object-50%-50% object-cover pointer-events-none size-full" src={imgNext1} />
      </div>
      <div className="absolute bg-[#f2f4f7] h-[565px] left-[90px] rounded-[20px] shadow-[-15px_18px_17px_0px_rgba(0,0,0,0.25)] top-[1396px] w-[550px]" />
      <div className="absolute bg-[#f2f4f7] h-[325px] left-[90px] rounded-tl-[20px] rounded-tr-[20px] top-[1391px] w-[550px]" />
      <div className="absolute bg-[#f2f4f7] h-[565px] left-[761px] rounded-[20px] shadow-[-15px_18px_17px_0px_rgba(0,0,0,0.25)] top-[1401px] w-[550px]" />
      <div className="absolute bg-[#f2f4f7] h-[325px] left-[761px] rounded-tl-[20px] rounded-tr-[20px] top-[1396px] w-[550px]" />
      <div className="absolute bg-[#f2f4f7] h-[565px] left-[1432px] rounded-[20px] shadow-[-15px_18px_17px_0px_rgba(0,0,0,0.25)] top-[1401px] w-[550px]" />
      <div className="absolute bg-[#f2f4f7] h-[325px] left-[1432px] rounded-tl-[20px] rounded-tr-[20px] top-[1396px] w-[550px]" />
      <div className="absolute bg-[#f2f4f7] h-[565px] left-[90px] rounded-[20px] shadow-[-15px_18px_17px_0px_rgba(0,0,0,0.25)] top-[2050px] w-[550px]" />
      <div className="absolute bg-[#f2f4f7] h-[325px] left-[90px] rounded-tl-[20px] rounded-tr-[20px] top-[2045px] w-[550px]" />
      <div className="absolute bg-[#f2f4f7] h-[565px] left-[761px] rounded-[20px] shadow-[-15px_18px_17px_0px_rgba(0,0,0,0.25)] top-[2055px] w-[550px]" />
      <div className="absolute bg-[#f2f4f7] h-[325px] left-[761px] rounded-tl-[20px] rounded-tr-[20px] top-[2050px] w-[550px]" />
      <div className="absolute left-[362px] size-[26px] top-[9px]" data-name="calendar 1">
        <img alt="" className="absolute inset-0 max-w-none object-50%-50% object-cover pointer-events-none size-full" src={imgCalendar1} />
      </div>
      <div className="absolute flex flex-col font-['Inter:Regular',sans-serif] font-normal h-[19px] justify-center leading-[0] left-[143px] not-italic text-[#98a2b3] text-[18px] top-[1743.5px] translate-y-[-50%] w-[149px]">
        <p className="leading-[18px]">20 Nov 2025</p>
      </div>
      <div className="absolute flex flex-col font-['Inter:Regular',sans-serif] font-normal h-[19px] justify-center leading-[0] left-[309px] not-italic text-[#98a2b3] text-[18px] top-[1743.5px] translate-y-[-50%] w-[149px]">
        <p className="leading-[18px]">5 min read</p>
      </div>
      <div className="absolute left-[115px] size-[20px] top-[1734px]" data-name="calendar (2) 1">
        <img alt="" className="absolute inset-0 max-w-none object-50%-50% object-cover pointer-events-none size-full" src={imgCalendar21} />
      </div>
      <div className="absolute left-[282px] size-[19px] top-[1734px]" data-name="clock (1) 1">
        <img alt="" className="absolute inset-0 max-w-none object-50%-50% object-cover pointer-events-none size-full" src={imgClock11} />
      </div>
      <div className="absolute flex flex-col font-['Inter:Medium',sans-serif] font-medium h-[60px] justify-center leading-[0] left-[115px] not-italic text-[18px] text-black top-[1794px] translate-y-[-50%] w-[508px]">
        <p className="leading-[18px]">AYO IKUT SERTA SURVEI PENILAIAN INTEGRITAS 2025 KPK</p>
      </div>
      <div className="absolute flex flex-col font-['Inter:Regular',sans-serif] font-normal h-[73px] justify-center leading-[0] left-[115px] not-italic text-[#475467] text-[16px] top-[1872.5px] translate-y-[-50%] w-[508px]">
        <p className="leading-[16px]">Komisi Pemberantasan Korupsi (KPK) mengundang seluruh masyarakat untuk berpartisipasi dalam Survei Penilaian Integritas 2025...</p>
      </div>
      <div className="absolute flex flex-col font-['Inter:Medium',sans-serif] font-medium h-[23px] justify-center leading-[0] left-[115px] not-italic text-[#f79009] text-[18px] top-[1932.5px] translate-y-[-50%] w-[194px]">
        <p className="leading-[18px]">Baca Selengkapnya</p>
      </div>
      <div className="absolute left-[309px] size-[17px] top-[1926px]" data-name="next 2">
        <img alt="" className="absolute inset-0 max-w-none object-50%-50% object-cover pointer-events-none size-full" src={imgNext1} />
      </div>
      <div className="absolute flex flex-col font-['Inter:Regular',sans-serif] font-normal h-[19px] justify-center leading-[0] left-[139px] not-italic text-[#98a2b3] text-[18px] top-[2396.5px] translate-y-[-50%] w-[149px]">
        <p className="leading-[18px]">10 Nov 2025</p>
      </div>
      <div className="absolute flex flex-col font-['Inter:Regular',sans-serif] font-normal h-[19px] justify-center leading-[0] left-[305px] not-italic text-[#98a2b3] text-[18px] top-[2396.5px] translate-y-[-50%] w-[149px]">
        <p className="leading-[18px]">5 min read</p>
      </div>
      <div className="absolute left-[111px] size-[20px] top-[2387px]" data-name="calendar (2) 4">
        <img alt="" className="absolute inset-0 max-w-none object-50%-50% object-cover pointer-events-none size-full" src={imgCalendar21} />
      </div>
      <div className="absolute left-[278px] size-[19px] top-[2387px]" data-name="clock (1) 4">
        <img alt="" className="absolute inset-0 max-w-none object-50%-50% object-cover pointer-events-none size-full" src={imgClock11} />
      </div>
      <div className="absolute flex flex-col font-['Inter:Medium',sans-serif] font-medium h-[60px] justify-center leading-[0] left-[111px] not-italic text-[18px] text-black top-[2447px] translate-y-[-50%] w-[508px]">
        <p className="leading-[18px]">STOP PENYALAHGUNAAN FASILITAS KANTOR</p>
      </div>
      <div className="absolute flex flex-col font-['Inter:Regular',sans-serif] font-normal h-[73px] justify-center leading-[0] left-[111px] not-italic text-[#475467] text-[16px] top-[2513.5px] translate-y-[-50%] w-[508px]">
        <p className="leading-[16px]">Himbauan kepada seluruh ASN dan pegawai untuk menggunakan fasilitas kantor sesuai dengan ketentuan yang berlaku...</p>
      </div>
      <div className="absolute flex flex-col font-['Inter:Medium',sans-serif] font-medium h-[23px] justify-center leading-[0] left-[111px] not-italic text-[#f79009] text-[18px] top-[2585.5px] translate-y-[-50%] w-[194px]">
        <p className="leading-[18px]">Baca Selengkapnya</p>
      </div>
      <div className="absolute left-[305px] size-[17px] top-[2579px]" data-name="next 5">
        <img alt="" className="absolute inset-0 max-w-none object-50%-50% object-cover pointer-events-none size-full" src={imgNext1} />
      </div>
      <div className="absolute flex flex-col font-['Inter:Regular',sans-serif] font-normal h-[19px] justify-center leading-[0] left-[810px] not-italic text-[#98a2b3] text-[18px] top-[2397.5px] translate-y-[-50%] w-[149px]">
        <p className="leading-[18px]">25 Okt 2025</p>
      </div>
      <div className="absolute flex flex-col font-['Inter:Regular',sans-serif] font-normal h-[19px] justify-center leading-[0] left-[976px] not-italic text-[#98a2b3] text-[18px] top-[2397.5px] translate-y-[-50%] w-[149px]">
        <p className="leading-[18px]">5 min read</p>
      </div>
      <div className="absolute left-[782px] size-[20px] top-[2388px]" data-name="calendar (2) 5">
        <img alt="" className="absolute inset-0 max-w-none object-50%-50% object-cover pointer-events-none size-full" src={imgCalendar21} />
      </div>
      <div className="absolute left-[949px] size-[19px] top-[2388px]" data-name="clock (1) 5">
        <img alt="" className="absolute inset-0 max-w-none object-50%-50% object-cover pointer-events-none size-full" src={imgClock11} />
      </div>
      <div className="absolute flex flex-col font-['Inter:Medium',sans-serif] font-medium h-[60px] justify-center leading-[0] left-[782px] not-italic text-[18px] text-black top-[2448px] translate-y-[-50%] w-[508px]">
        <p className="leading-[18px]">PEMKOT SURABAYA SIAPKAN RP 192,8 M UNTUK BEASISWA 24.000 MAHASISWA</p>
      </div>
      <div className="absolute flex flex-col font-['Inter:Regular',sans-serif] font-normal h-[73px] justify-center leading-[0] left-[782px] not-italic text-[#475467] text-[16px] top-[2522.5px] translate-y-[-50%] w-[508px]">
        <p className="leading-[16px]">Pemerintah Kota Surabaya mengalokasikan dana sebesar Rp 192,8 Miliar untuk program beasiswa bagi 24.000 mahasiswa...</p>
      </div>
      <div className="absolute flex flex-col font-['Inter:Medium',sans-serif] font-medium h-[23px] justify-center leading-[0] left-[782px] not-italic text-[#f79009] text-[18px] top-[2586.5px] translate-y-[-50%] w-[194px]">
        <p className="leading-[18px]">Baca Selengkapnya</p>
      </div>
      <div className="absolute left-[976px] size-[17px] top-[2580px]" data-name="next 6">
        <img alt="" className="absolute inset-0 max-w-none object-50%-50% object-cover pointer-events-none size-full" src={imgNext1} />
      </div>
      <div className="absolute flex flex-col font-['Inter:Regular',sans-serif] font-normal h-[19px] justify-center leading-[0] left-[810px] not-italic text-[#98a2b3] text-[18px] top-[1743.5px] translate-y-[-50%] w-[149px]">
        <p className="leading-[18px]">18 Nov 2025</p>
      </div>
      <div className="absolute flex flex-col font-['Inter:Regular',sans-serif] font-normal h-[19px] justify-center leading-[0] left-[976px] not-italic text-[#98a2b3] text-[18px] top-[1743.5px] translate-y-[-50%] w-[149px]">
        <p className="leading-[18px]">5 min read</p>
      </div>
      <div className="absolute left-[782px] size-[20px] top-[1734px]" data-name="calendar (2) 2">
        <img alt="" className="absolute inset-0 max-w-none object-50%-50% object-cover pointer-events-none size-full" src={imgCalendar21} />
      </div>
      <div className="absolute left-[949px] size-[19px] top-[1734px]" data-name="clock (1) 2">
        <img alt="" className="absolute inset-0 max-w-none object-50%-50% object-cover pointer-events-none size-full" src={imgClock11} />
      </div>
      <div className="absolute flex flex-col font-['Inter:Medium',sans-serif] font-medium h-[60px] justify-center leading-[0] left-[782px] not-italic text-[18px] text-black top-[1794px] translate-y-[-50%] w-[508px]">
        <p className="leading-[18px]">LAYANAN PENGUJIAN KENDARAAN BERMOTOR KOTA SURABAYA</p>
      </div>
      <div className="absolute flex flex-col font-['Inter:Regular',sans-serif] font-normal h-[73px] justify-center leading-[0] left-[782px] not-italic text-[#475467] text-[16px] top-[1872.5px] translate-y-[-50%] w-[508px]">
        <p className="leading-[16px]">Dinas Perhubungan Kota Surabaya menyediakan layanan pengujian kendaraan bermotor yang cepat dan terpercaya untuk seluruh masyarakat...</p>
      </div>
      <div className="absolute flex flex-col font-['Inter:Medium',sans-serif] font-medium h-[23px] justify-center leading-[0] left-[782px] not-italic text-[#f79009] text-[18px] top-[1932.5px] translate-y-[-50%] w-[194px]">
        <p className="leading-[18px]">Baca Selengkapnya</p>
      </div>
      <div className="absolute left-[976px] size-[17px] top-[1926px]" data-name="next 3">
        <img alt="" className="absolute inset-0 max-w-none object-50%-50% object-cover pointer-events-none size-full" src={imgNext1} />
      </div>
      <div className="absolute flex flex-col font-['Inter:Regular',sans-serif] font-normal h-[19px] justify-center leading-[0] left-[1481px] not-italic text-[#98a2b3] text-[18px] top-[1743.5px] translate-y-[-50%] w-[149px]">
        <p className="leading-[18px]">15 Nov 2025</p>
      </div>
      <div className="absolute flex flex-col font-['Inter:Regular',sans-serif] font-normal h-[19px] justify-center leading-[0] left-[1647px] not-italic text-[#98a2b3] text-[18px] top-[1743.5px] translate-y-[-50%] w-[149px]">
        <p className="leading-[18px]">5 min read</p>
      </div>
      <div className="absolute left-[1453px] size-[20px] top-[1734px]" data-name="calendar (2) 3">
        <img alt="" className="absolute inset-0 max-w-none object-50%-50% object-cover pointer-events-none size-full" src={imgCalendar21} />
      </div>
      <div className="absolute left-[1620px] size-[19px] top-[1734px]" data-name="clock (1) 3">
        <img alt="" className="absolute inset-0 max-w-none object-50%-50% object-cover pointer-events-none size-full" src={imgClock11} />
      </div>
      <div className="absolute flex flex-col font-['Inter:Medium',sans-serif] font-medium h-[60px] justify-center leading-[0] left-[1453px] not-italic text-[18px] text-black top-[1794px] translate-y-[-50%] w-[508px]">
        <p className="leading-[18px]">LAYANAN PENGECEKAN DAN PENGAMBILAN REKAMAN CCTV</p>
      </div>
      <div className="absolute flex flex-col font-['Inter:Regular',sans-serif] font-normal h-[73px] justify-center leading-[0] left-[1453px] not-italic text-[#475467] text-[16px] top-[1872.5px] translate-y-[-50%] w-[508px]">
        <p className="leading-[16px]">Masyarakat dapat mengakses layanan pengecekan dan pengambilan rekaman CCTV untuk keperluan keamanan dan monitoring lalu lintas...</p>
      </div>
      <div className="absolute flex flex-col font-['Inter:Medium',sans-serif] font-medium h-[23px] justify-center leading-[0] left-[1453px] not-italic text-[#f79009] text-[18px] top-[1932.5px] translate-y-[-50%] w-[194px]">
        <p className="leading-[18px]">Baca Selengkapnya</p>
      </div>
      <div className="absolute left-[1647px] size-[17px] top-[1926px]" data-name="next 4">
        <img alt="" className="absolute inset-0 max-w-none object-50%-50% object-cover pointer-events-none size-full" src={imgNext1} />
      </div>
      <div className="absolute h-[296px] left-[244px] shadow-[-15px_18px_17px_0px_rgba(0,0,0,0.25)] top-[1406px] w-[241px]" data-name="26">
        <img alt="" className="absolute inset-0 max-w-none object-50%-50% object-cover pointer-events-none size-full" src={img26} />
      </div>
      <div className="absolute h-[325px] left-[761px] rounded-tl-[20px] rounded-tr-[20px] top-[1396px] w-[550px]" data-name="27">
        <div className="absolute inset-0 overflow-hidden pointer-events-none rounded-tl-[20px] rounded-tr-[20px]">
          <img alt="" className="absolute h-[105.85%] left-[-0.04%] max-w-none top-0 w-[100.07%]" src={img27} />
        </div>
      </div>
      <div className="absolute h-[302px] left-[1586px] shadow-[-15px_18px_17px_0px_rgba(0,0,0,0.25)] top-[1408px] w-[241px]" data-name="28">
        <img alt="" className="absolute inset-0 max-w-none object-50%-50% object-cover pointer-events-none size-full" src={img28} />
      </div>
      <div className="absolute h-[295px] left-[247px] shadow-[-15px_18px_17px_0px_rgba(0,0,0,0.25)] top-[2060px] w-[236px]" data-name="29">
        <img alt="" className="absolute inset-0 max-w-none object-50%-50% object-cover pointer-events-none size-full" src={img29} />
      </div>
      <div className="absolute h-[295px] left-[933px] shadow-[-15px_18px_17px_0px_rgba(0,0,0,0.25)] top-[2065px] w-[236px]" data-name="31">
        <img alt="" className="absolute inset-0 max-w-none object-50%-50% object-cover pointer-events-none size-full" src={img31} />
      </div>
      <div className="absolute bg-[#f79009] h-[36px] left-[101px] rounded-[20px] top-[1401px] w-[181px]" data-name="Rectangle" />
      <div className="absolute flex flex-col font-['Inter:Bold',sans-serif] font-bold h-[35px] justify-center leading-[0] left-[135px] not-italic text-[16px] text-white top-[1418.5px] translate-y-[-50%] w-[114px]">
        <p className="leading-[16px]">Pengumuman</p>
      </div>
      <div className="absolute bg-[#f79009] h-[36px] left-[768px] rounded-[20px] top-[1401px] w-[153px]" data-name="Rectangle" />
      <div className="absolute flex flex-col font-['Inter:Bold',sans-serif] font-bold h-[35px] justify-center leading-[0] left-[811px] not-italic text-[16px] text-white top-[1418.5px] translate-y-[-50%] w-[67px]">
        <p className="leading-[16px]">Layanan</p>
      </div>
      <div className="absolute bg-[#f79009] h-[36px] left-[101px] rounded-[20px] top-[2055px] w-[181px]" data-name="Rectangle" />
      <div className="absolute flex flex-col font-['Inter:Bold',sans-serif] font-bold h-[35px] justify-center leading-[0] left-[135px] not-italic text-[16px] text-white top-[2072.5px] translate-y-[-50%] w-[113px]">
        <p className="leading-[16px]">Pengumuman</p>
      </div>
      <div className="absolute bg-[#f79009] h-[36px] left-[768px] rounded-[20px] top-[2055px] w-[181px]" data-name="Rectangle" />
      <div className="absolute flex flex-col font-['Inter:Bold',sans-serif] font-bold h-[35px] justify-center leading-[0] left-[813px] not-italic text-[16px] text-white top-[2072.5px] translate-y-[-50%] w-[91px]">
        <p className="leading-[16px]">Pendidikan</p>
      </div>
      <div className="absolute bg-[#f79009] h-[36px] left-[1439px] rounded-[20px] top-[1401px] w-[155px]" data-name="Rectangle" />
      <div className="absolute flex flex-col font-['Inter:Bold',sans-serif] font-bold h-[35px] justify-center leading-[0] left-[1477px] not-italic text-[16px] text-white top-[1418.5px] translate-y-[-50%] w-[79px]">
        <p className="leading-[16px]">Teknologi</p>
      </div>
      <div className="absolute bg-white border border-[#667085] border-solid h-[616px] left-[90px] rounded-[20px] top-[2989px] w-[874px]" />
      <div className="absolute bg-gradient-to-l from-[#457fc9] h-[616px] left-[1083px] rounded-[20px] to-[#1e5ba8] top-[2989px] w-[874px]" />
      <div className="absolute flex flex-col font-['Inter:Bold',sans-serif] font-bold h-[79px] justify-center leading-[0] left-[129px] not-italic text-[48px] text-black top-[3052.5px] translate-y-[-50%] w-[439px]">
        <p className="leading-[60px]">Convention Hall</p>
      </div>
      <div className="absolute bg-[#12b76a] h-[43px] left-[773px] rounded-[20px] top-[3029px] w-[153px]" />
      <div className="absolute flex flex-col font-['Inter:Semi_Bold',sans-serif] font-semibold h-[43px] justify-center leading-[0] left-[826px] not-italic text-[20px] text-white top-[3050.5px] translate-y-[-50%] w-[88px]">
        <p className="leading-[20px]">Tersedia</p>
      </div>
      <div className="absolute left-[789px] size-[24px] top-[3039px]" data-name="rise 1">
        <img alt="" className="absolute inset-0 max-w-none object-50%-50% object-cover pointer-events-none size-full" src={imgRise1} />
      </div>
      <div className="absolute bg-gradient-to-r border border-[rgba(16,185,129,0.37)] border-solid from-[#d8faef] h-[127px] left-[129px] rounded-[20px] to-[#ffffff] top-[3137px] w-[797px]" />
      <div className="absolute bg-[#039855] left-[170px] rounded-[20px] shadow-[-1px_5px_10px_0px_rgba(0,0,0,0.3)] size-[80px] top-[3167px]" />
      <div className="absolute left-[187px] size-[46px] top-[3184px]" data-name="motorbike 1">
        <img alt="" className="absolute inset-0 max-w-none object-50%-50% object-cover pointer-events-none size-full" src={imgMotorbike1} />
      </div>
      <div className="absolute bg-gradient-to-r border border-[rgba(16,185,129,0.37)] border-solid from-[#d8faef] h-[127px] left-[129px] rounded-[20px] to-[#ffffff] top-[3329px] w-[797px]" />
      <div className="absolute bg-[#039855] left-[170px] rounded-[20px] shadow-[-1px_5px_10px_0px_rgba(0,0,0,0.3)] size-[80px] top-[3353px]" />
      <div className="absolute h-0 left-[649px] top-[3290px] w-[273px]">
        <div className="absolute bottom-[-5px] left-0 right-[-1.83%] top-[-5px]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 278 10">
            <path d={svgPaths.p506ba80} fill="var(--stroke-0, #98A2B3)" id="Line 23" />
          </svg>
        </div>
      </div>
      <div className="absolute h-0 left-[594px] top-[3483px] w-[328px]">
        <div className="absolute bottom-[-5px] left-0 right-[-1.52%] top-[-5px]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 333 10">
            <path d={svgPaths.p1c5db680} fill="var(--stroke-0, #98A2B3)" id="Line 25" />
          </svg>
        </div>
      </div>
      <div className="absolute h-0 left-[137px] top-[3290px] w-[564px]">
        <div className="absolute bottom-[-5px] left-[-0.89%] right-0 top-[-5px]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 569 10">
            <path d={svgPaths.p33752200} fill="var(--stroke-0, #039855)" id="Line 22" />
          </svg>
        </div>
      </div>
      <div className="absolute h-0 left-[137px] top-[3483px] w-[512.001px]">
        <div className="absolute bottom-[-5px] left-[-0.98%] right-0 top-[-5px]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 517 10">
            <path d={svgPaths.p2fdece00} fill="var(--stroke-0, #039855)" id="Line 24" />
          </svg>
        </div>
      </div>
      <div className="absolute flex flex-col font-['Inter:Semi_Bold',sans-serif] font-semibold h-[53px] justify-center leading-[0] left-[280px] not-italic text-[#667085] text-[20px] top-[3190.5px] translate-y-[-50%] w-[113px]">
        <p className="leading-[20px]">Motor (R2)</p>
      </div>
      <div className="absolute flex flex-col font-['Inter:Semi_Bold',sans-serif] font-semibold h-[53px] justify-center leading-[0] left-[280px] not-italic text-[#667085] text-[20px] top-[3373.5px] translate-y-[-50%] w-[113px]">
        <p className="leading-[20px]">Mobil (R4)</p>
      </div>
      <div className="absolute flex flex-col font-['Inter:Semi_Bold',sans-serif] font-semibold h-[43px] justify-center leading-[0] left-[280px] not-italic text-[20px] text-black top-[3227.5px] translate-y-[-50%] w-[205px]">
        <p className="leading-[20px]">100 Slot Tersedia</p>
      </div>
      <div className="absolute flex flex-col font-['Inter:Semi_Bold',sans-serif] font-semibold h-[43px] justify-center leading-[0] left-[280px] not-italic text-[20px] text-black top-[3411.5px] translate-y-[-50%] w-[205px]">
        <p className="leading-[20px]">50 Slot Tersedia</p>
      </div>
      <div className="absolute flex flex-col font-['Inter:Bold',sans-serif] font-bold h-[68px] justify-center leading-[0] left-[808px] not-italic text-[#039855] text-[48px] top-[3194px] translate-y-[-50%] w-[98px]">
        <p className="leading-[60px]">100</p>
      </div>
      <div className="absolute flex flex-col font-['Inter:Semi_Bold',sans-serif] font-semibold h-[43px] justify-center leading-[0] left-[826px] not-italic text-[#667085] text-[16px] top-[3229.5px] translate-y-[-50%] w-[88px]">
        <p className="leading-[16px]">/ 150 Total</p>
      </div>
      <div className="absolute flex flex-col font-['Inter:Bold',sans-serif] font-bold h-[68px] justify-center leading-[0] left-[842px] not-italic text-[#039855] text-[48px] top-[3381px] translate-y-[-50%] w-[72px]">
        <p className="leading-[60px]">50</p>
      </div>
      <div className="absolute flex flex-col font-['Inter:Semi_Bold',sans-serif] font-semibold h-[43px] justify-center leading-[0] left-[840px] not-italic text-[#667085] text-[16px] top-[3413.5px] translate-y-[-50%] w-[75px]">
        <p className="leading-[16px]">/ 80 Total</p>
      </div>
      <div className="absolute flex flex-col font-['Inter:Bold',sans-serif] font-bold h-[67px] justify-center leading-[0] left-[137px] not-italic text-[#3f88d3] text-[16px] top-[3548.5px] translate-y-[-50%] w-[152px]">
        <p className="leading-[16px]">{`Lihat Lebih Banyak `}</p>
      </div>
      <div className="absolute left-[289px] size-[18px] top-[3540px]" data-name="arrow 1">
        <img alt="" className="absolute inset-0 max-w-none object-50%-50% object-cover pointer-events-none size-full" src={imgArrow1} />
      </div>
      <div className="absolute flex flex-col font-['Inter:Bold',sans-serif] font-bold h-[109px] justify-center leading-[0] left-[1138px] not-italic text-[48px] text-white top-[3057.5px] translate-y-[-50%] w-[263px]">
        <p className="leading-[60px]">Info Parkir</p>
      </div>
      <div className="absolute flex flex-col font-['Inter:Medium',sans-serif] font-medium h-[67px] justify-center leading-[0] left-[1138px] not-italic text-[#eaecf0] text-[24px] top-[3141.5px] translate-y-[-50%] w-[788px]">
        <p className="leading-[24px]">Sistem parkir digital terintegrasi untuk kenyamanan Anda. Pantau ketersediaan parkir secara real-time.</p>
      </div>
      <div className="absolute left-[1138px] size-[15px] top-[3230px]">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 15 15">
          <circle cx="7.5" cy="7.5" fill="var(--fill-0, #F79009)" id="Ellipse 6" r="7.5" />
        </svg>
      </div>
      <div className="absolute left-[1138px] size-[15px] top-[3290px]">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 15 15">
          <circle cx="7.5" cy="7.5" fill="var(--fill-0, #F79009)" id="Ellipse 6" r="7.5" />
        </svg>
      </div>
      <div className="absolute left-[1138px] size-[15px] top-[3350px]">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 15 15">
          <circle cx="7.5" cy="7.5" fill="var(--fill-0, #F79009)" id="Ellipse 6" r="7.5" />
        </svg>
      </div>
      <div className="absolute flex flex-col font-['Inter:Medium',sans-serif] font-medium h-[70px] justify-center leading-[0] left-[1186px] not-italic text-[20px] text-white top-[3238px] translate-y-[-50%] w-[380px]">
        <p className="leading-[20px]">Update otomatis setiap 5 menit</p>
      </div>
      <div className="absolute flex flex-col font-['Inter:Medium',sans-serif] font-medium h-[70px] justify-center leading-[0] left-[1186px] not-italic text-[20px] text-white top-[3298px] translate-y-[-50%] w-[380px]">
        <p className="leading-[20px]">Notifikasi saat slot tersedia</p>
      </div>
      <div className="absolute flex flex-col font-['Inter:Medium',sans-serif] font-medium h-[70px] justify-center leading-[0] left-[1186px] not-italic text-[20px] text-white top-[3358px] translate-y-[-50%] w-[380px]">
        <p className="leading-[20px]">Pembayaran digital terintegrasi</p>
      </div>
      <div className="absolute bg-[#f79009] h-[88px] left-[1214px] rounded-[20px] top-[3464px] w-[611px]" />
      <div className="absolute flex flex-col font-['Inter:Medium',sans-serif] font-medium h-[91px] justify-center leading-[0] left-[1409px] not-italic text-[24px] text-white top-[3506.5px] translate-y-[-50%] w-[221px]">
        <p className="leading-[24px]">Download Aplikasi</p>
      </div>
      <div className="absolute h-0 left-[98px] top-[3765px] w-[116px]">
        <div className="absolute bottom-0 left-0 right-0 top-[-8px]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 116 8">
            <line id="Line 31" stroke="var(--stroke-0, #F79009)" strokeLinecap="round" strokeWidth="8" x1="4" x2="112" y1="4" y2="4" />
          </svg>
        </div>
      </div>
      <div className="absolute h-0 left-[98px] top-[3765px] w-[116px]">
        <div className="absolute bottom-0 left-0 right-0 top-[-8px]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 116 8">
            <line id="Line 31" stroke="var(--stroke-0, #F79009)" strokeLinecap="round" strokeWidth="8" x1="4" x2="112" y1="4" y2="4" />
          </svg>
        </div>
      </div>
      <div className="absolute flex flex-col font-['Inter:Bold',sans-serif] font-bold h-[87px] justify-center leading-[0] left-[94px] not-italic text-[#2c5e8f] text-[60px] top-[3819.5px] translate-y-[-50%] w-[469px]">
        <p className="leading-[72px]">SK KADISHUB</p>
      </div>
      <div className="absolute flex flex-col font-['Inter:Medium',sans-serif] font-medium h-[85px] justify-center leading-[0] left-[96px] not-italic text-[#475467] text-[20px] top-[3879.5px] translate-y-[-50%] w-[839px]">
        <p className="leading-[20px]">Standar Pelayanan Publik</p>
      </div>
      <div className="absolute h-0 left-[98px] top-[4610px] w-[116px]">
        <div className="absolute bottom-0 left-0 right-0 top-[-8px]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 116 8">
            <line id="Line 31" stroke="var(--stroke-0, #F79009)" strokeLinecap="round" strokeWidth="8" x1="4" x2="112" y1="4" y2="4" />
          </svg>
        </div>
      </div>
      <div className="absolute h-0 left-[98px] top-[4610px] w-[116px]">
        <div className="absolute bottom-0 left-0 right-0 top-[-8px]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 116 8">
            <line id="Line 31" stroke="var(--stroke-0, #F79009)" strokeLinecap="round" strokeWidth="8" x1="4" x2="112" y1="4" y2="4" />
          </svg>
        </div>
      </div>
      <div className="absolute flex flex-col font-['Inter:Bold',sans-serif] font-bold h-[87px] justify-center leading-[0] left-[94px] not-italic text-[#2c5e8f] text-[60px] top-[4664.5px] translate-y-[-50%] w-[469px]">
        <p className="leading-[72px]">LINK</p>
      </div>
      <div className="absolute flex flex-col font-['Inter:Medium',sans-serif] font-medium h-[85px] justify-center leading-[0] left-[96px] not-italic text-[#475467] text-[20px] top-[4724.5px] translate-y-[-50%] w-[839px]">
        <p className="leading-[20px]">Akses Cepat ke Layanan Terkait</p>
      </div>
      <div className="absolute bg-white h-[518px] left-[90px] rounded-[50px] shadow-[-2px_10px_20px_0px_rgba(0,0,0,0.25)] top-[3972px] w-[1867px]" />
      <div className="absolute h-0 left-[174px] top-[4386px] w-[1700px]">
        <div className="absolute bottom-0 left-0 right-0 top-[-2px]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 1700 2">
            <line id="Line 28" stroke="var(--stroke-0, #667085)" strokeWidth="2" x2="1700" y1="1" y2="1" />
          </svg>
        </div>
      </div>
      <div className="absolute bg-gradient-to-r from-[#2062af] left-[174px] rounded-[30px] size-[155px] to-[rgba(35,107,184,0.9)] top-[4037px]" />
      <div className="absolute left-[212px] size-[80px] top-[4075px]" data-name="google-docs 1">
        <img alt="" className="absolute inset-0 max-w-none object-50%-50% object-cover pointer-events-none size-full" src={imgGoogleDocs1} />
      </div>
      <div className="absolute flex flex-col font-['Inter:Bold',sans-serif] font-bold h-[99px] justify-center leading-[0] left-[377px] not-italic text-[36px] text-black top-[4074.5px] translate-y-[-50%] w-[1522px]">
        <p className="leading-[44px]">Standar Pelayanan Dinas Perhubungan Kota Surabaya 2024</p>
      </div>
      <div className="absolute flex flex-col font-['Inter:Medium',sans-serif] font-medium h-[54px] justify-center leading-[0] left-[424px] not-italic text-[#667085] text-[24px] top-[4120px] translate-y-[-50%] w-[160px]">
        <p className="leading-[24px]">Terakreditas</p>
      </div>
      <div className="absolute flex flex-col font-['Inter:Medium',sans-serif] font-medium h-[124px] justify-center leading-[0] left-[377px] not-italic text-[#667085] text-[30px] top-[4204px] translate-y-[-50%] w-[1497px]">
        <p className="leading-[30px]">Dokumen resmi yang berisi standar pelayanan publik di lingkungan Dinas Perhubungan Kota Surabaya untuk tahun 2024. Mencakup seluruh aspek layanan dari pendaftaran hingga penyelesaian dokumen.</p>
      </div>
      <div className="absolute flex flex-col font-['Inter:Medium',sans-serif] font-medium h-[54px] justify-center leading-[0] left-[640px] not-italic text-[#667085] text-[24px] top-[4120px] translate-y-[-50%] w-[160px]">
        <p className="leading-[24px]">Aktif</p>
      </div>
      <div className="absolute left-[383px] size-[30px] top-[4105px]" data-name="badge 1">
        <img alt="" className="absolute inset-0 max-w-none object-50%-50% object-cover pointer-events-none size-full" src={imgBadge1} />
      </div>
      <div className="absolute left-[595px] size-[34px] top-[4103px]" data-name="checkmark 1">
        <img alt="" className="absolute inset-0 max-w-none object-50%-50% object-cover pointer-events-none size-full" src={imgCheckmark1} />
      </div>
      <div className="absolute bg-[#f79009] h-[83px] left-[377px] rounded-[20px] top-[4274px] w-[299px]" />
      <div className="absolute bg-white border-[#336fab] border-[3px] border-solid h-[83px] left-[737px] rounded-[20px] top-[4274px] w-[299px]" />
      <div className="absolute left-[780px] size-[40px] top-[4296px]" data-name="google-docs (2) 1">
        <img alt="" className="absolute inset-0 max-w-none object-50%-50% object-cover pointer-events-none size-full" src={imgGoogleDocs21} />
      </div>
      <div className="absolute flex flex-col font-['Inter:Bold',sans-serif] font-bold h-[73px] justify-center leading-[0] left-[465px] not-italic text-[20px] text-white top-[4315.5px] translate-y-[-50%] w-[184px]">
        <p className="leading-[20px]">Unduh Dokumen</p>
      </div>
      <div className="absolute flex flex-col font-['Inter:Semi_Bold',sans-serif] font-semibold h-[60px] justify-center leading-[0] left-[845px] not-italic text-[#2c5e8f] text-[20px] top-[4319px] translate-y-[-50%] w-[143px]">
        <p className="leading-[20px]">Lihat Preview</p>
      </div>
      <div className="absolute left-[752px] size-[80px] top-[4279px]" data-name="google-docs 2" />
      <div className="absolute left-[413px] size-[39px] top-[4296px]" data-name="downloads 1">
        <img alt="" className="absolute inset-0 max-w-none object-50%-50% object-cover pointer-events-none size-full" src={imgDownloads5} />
      </div>
      <div className="absolute flex flex-col font-['Inter:Semi_Bold',sans-serif] font-semibold h-[79px] justify-center leading-[0] left-[494px] not-italic text-[#336fab] text-[48px] top-[4422.5px] translate-y-[-50%] w-[69px]">
        <p className="leading-[60px]">45</p>
      </div>
      <div className="absolute flex flex-col font-['Inter:Regular',sans-serif] font-normal h-[50px] justify-center leading-[0] left-[494px] not-italic text-[#667085] text-[16px] top-[4457px] translate-y-[-50%] w-[75px]">
        <p className="leading-[16px]">Halaman</p>
      </div>
      <div className="absolute flex flex-col font-['Inter:Semi_Bold',sans-serif] font-semibold h-[79px] justify-center leading-[0] left-[1006px] not-italic text-[#336fab] text-[48px] top-[4422.5px] translate-y-[-50%] w-[69px]">
        <p className="leading-[60px]">12</p>
      </div>
      <div className="absolute flex flex-col font-['Inter:Regular',sans-serif] font-normal h-[50px] justify-center leading-[0] left-[997px] not-italic text-[#667085] text-[16px] top-[4457px] translate-y-[-50%] w-[69px]">
        <p className="leading-[16px]">Layanan</p>
      </div>
      <div className="absolute flex flex-col font-['Inter:Semi_Bold',sans-serif] font-semibold h-[79px] justify-center leading-[0] left-[1497px] not-italic text-[#336fab] text-[48px] top-[4422.5px] translate-y-[-50%] w-[154px]">
        <p className="leading-[60px]">2.5K +</p>
      </div>
      <div className="absolute flex flex-col font-['Inter:Regular',sans-serif] font-normal h-[50px] justify-center leading-[0] left-[1530px] not-italic text-[#667085] text-[16px] top-[4457px] translate-y-[-50%] w-[110px]">
        <p className="leading-[16px]">Download</p>
      </div>
      <div className="absolute bg-white h-[250px] left-[98px] rounded-[30px] shadow-[-2px_7px_30px_0px_rgba(0,0,0,0.3)] top-[4818px] w-[370px]" />
      <div className="absolute bg-white h-[250px] left-[592px] rounded-[30px] shadow-[-2px_7px_30px_0px_rgba(0,0,0,0.3)] top-[4817px] w-[370px]" />
      <div className="absolute bg-white h-[250px] left-[1086px] rounded-[30px] shadow-[-2px_7px_30px_0px_rgba(0,0,0,0.3)] top-[4818px] w-[370px]" />
      <div className="absolute bg-white h-[250px] left-[1580px] rounded-[30px] shadow-[-2px_7px_30px_0px_rgba(0,0,0,0.3)] top-[4818px] w-[370px]" />
      <div className="absolute bg-[#336fab] left-[124px] rounded-[20px] shadow-[0px_4px_4px_0px_rgba(0,0,0,0.25)] size-[90px] top-[4861px]" />
      <div className="absolute bg-[#3f88d3] left-[631px] rounded-[20px] shadow-[0px_4px_4px_0px_rgba(0,0,0,0.25)] size-[90px] top-[4861px]" />
      <div className="absolute bg-[#fdb022] left-[1125px] rounded-[20px] shadow-[0px_4px_4px_0px_rgba(0,0,0,0.25)] size-[90px] top-[4861px]" />
      <div className="absolute bg-[#12b76a] left-[1606px] rounded-[20px] shadow-[0px_4px_4px_0px_rgba(0,0,0,0.25)] size-[90px] top-[4861px]" />
      <div className="absolute left-[1623px] size-[55px] top-[4878px]" data-name="message 1">
        <img alt="" className="absolute inset-0 max-w-none object-50%-50% object-cover pointer-events-none size-full" src={imgMessage1} />
      </div>
      <div className="absolute left-[1139px] size-[61px] top-[4875px]" data-name="law 1">
        <img alt="" className="absolute inset-0 max-w-none object-50%-50% object-cover pointer-events-none size-full" src={imgLaw1} />
      </div>
      <div className="absolute left-[645px] size-[62px] top-[4875px]" data-name="city-hall 1">
        <img alt="" className="absolute inset-0 max-w-none object-50%-50% object-cover pointer-events-none size-full" src={imgCityHall1} />
      </div>
      <div className="absolute left-[141px] size-[55px] top-[4878px]" data-name="skyline (1) 1">
        <img alt="" className="absolute inset-0 max-w-none object-50%-50% object-cover pointer-events-none size-full" src={imgSkyline11} />
      </div>
      <div className="absolute flex flex-col font-['Inter:Semi_Bold',sans-serif] font-semibold h-[53px] justify-center leading-[0] left-[124px] not-italic text-[#101828] text-[20px] top-[4996.5px] translate-y-[-50%] w-[304px]">
        <p className="leading-[20px]">Pemerintah Kota Surabaya</p>
      </div>
      <div className="absolute flex flex-col font-['Inter:Semi_Bold',sans-serif] font-semibold h-[53px] justify-center leading-[0] left-[631px] not-italic text-[#101828] text-[20px] top-[5010.5px] translate-y-[-50%] w-[316px]">
        <p className="leading-[20px]">Kementerian Perhubungan Republik Indonesia</p>
      </div>
      <div className="absolute flex flex-col font-['Inter:Semi_Bold',sans-serif] font-semibold h-[53px] justify-center leading-[0] left-[1125px] not-italic text-[#101828] text-[20px] top-[4996.5px] translate-y-[-50%] w-[316px]">
        <p className="leading-[20px]">PERDA dan PERWALI</p>
      </div>
      <div className="absolute flex flex-col font-['Inter:Semi_Bold',sans-serif] font-semibold h-[53px] justify-center leading-[0] left-[1607px] not-italic text-[#101828] text-[20px] top-[5010.5px] translate-y-[-50%] w-[316px]">
        <p className="leading-[20px]">Pengaduan Online Media Center Surabaya</p>
      </div>
      <div className="absolute bg-[#f2f4f7] h-[269px] left-[94px] rounded-[30px] shadow-[-3px_6px_25px_0px_rgba(0,0,0,0.4)] top-[5414px] w-[417px]" />
      <div className="absolute bg-[#f2f4f7] h-[269px] left-[827px] rounded-[30px] shadow-[-3px_6px_25px_0px_rgba(0,0,0,0.4)] top-[5414px] w-[417px]" />
      <div className="absolute bg-[#f2f4f7] h-[269px] left-[1533px] rounded-[30px] shadow-[-3px_6px_25px_0px_rgba(0,0,0,0.4)] top-[5414px] w-[417px]" />
      <div className="absolute bg-gradient-to-r from-[#2062af] left-[122px] rounded-[20px] size-[90px] to-[rgba(35,107,184,0.9)] top-[5440px]" />
      <div className="absolute bg-gradient-to-r from-[#0aa775] left-[857px] rounded-[20px] size-[90px] to-[rgba(10,167,117,0.8)] top-[5440px]" />
      <div className="absolute bg-gradient-to-r from-[#f39c12] left-[1562px] rounded-[20px] size-[90px] to-[rgba(243,156,18,0.69)] top-[5440px]" />
      <div className="absolute left-[1576px] size-[62px] top-[5457px]" data-name="bus 1">
        <img alt="" className="absolute inset-0 max-w-none object-50%-50% object-cover pointer-events-none size-full" src={imgBus1} />
      </div>
      <div className="absolute bg-[#1d2939] h-[53px] left-[130px] rounded-[30px] top-[5603px] w-[346px]" />
      <div className="absolute flex flex-col font-['Inter:Semi_Bold',sans-serif] font-semibold h-[57px] justify-center leading-[0] left-[224px] not-italic text-[20px] text-white top-[5629.5px] translate-y-[-50%] w-[198px]">
        <p className="leading-[20px]">Download Aplikasi</p>
      </div>
      <div className="absolute left-[187px] size-[25px] top-[5617px]" data-name="downloads 2">
        <img alt="" className="absolute inset-0 max-w-none object-50%-50% object-cover pointer-events-none size-full" src={imgDownloads5} />
      </div>
      <div className="absolute bg-[#1d2939] h-[53px] left-[863px] rounded-[30px] top-[5601px] w-[346px]" />
      <div className="absolute flex flex-col font-['Inter:Semi_Bold',sans-serif] font-semibold h-[57px] justify-center leading-[0] left-[957px] not-italic text-[20px] text-white top-[5627.5px] translate-y-[-50%] w-[198px]">
        <p className="leading-[20px]">Download Aplikasi</p>
      </div>
      <div className="absolute left-[920px] size-[25px] top-[5615px]" data-name="downloads 3">
        <img alt="" className="absolute inset-0 max-w-none object-50%-50% object-cover pointer-events-none size-full" src={imgDownloads5} />
      </div>
      <div className="absolute bg-[#1d2939] h-[53px] left-[1569px] rounded-[30px] top-[5601px] w-[346px]" />
      <div className="absolute flex flex-col font-['Inter:Semi_Bold',sans-serif] font-semibold h-[57px] justify-center leading-[0] left-[1663px] not-italic text-[20px] text-white top-[5627.5px] translate-y-[-50%] w-[198px]">
        <p className="leading-[20px]">Download Aplikasi</p>
      </div>
      <div className="absolute left-[1626px] size-[25px] top-[5615px]" data-name="downloads 4">
        <img alt="" className="absolute inset-0 max-w-none object-50%-50% object-cover pointer-events-none size-full" src={imgDownloads5} />
      </div>
      <div className="absolute bg-[#f2f4f7] h-[269px] left-[826px] rounded-[30px] shadow-[-3px_6px_25px_0px_rgba(0,0,0,0.4)] top-[5756px] w-[417px]" />
      <div className="absolute bg-[#f2f4f7] h-[269px] left-[1532px] rounded-[30px] shadow-[-3px_6px_25px_0px_rgba(0,0,0,0.4)] top-[5756px] w-[417px]" />
      <div className="absolute bg-[#7a42e6] left-[856px] rounded-[20px] size-[90px] top-[5782px]" />
      <div className="absolute bg-[#d6347c] left-[1561px] rounded-[20px] size-[90px] top-[5782px]" />
      <div className="absolute bg-[#1d2939] h-[53px] left-[862px] rounded-[30px] top-[5943px] w-[346px]" />
      <div className="absolute flex flex-col font-['Inter:Semi_Bold',sans-serif] font-semibold h-[57px] justify-center leading-[0] left-[956px] not-italic text-[20px] text-white top-[5969.5px] translate-y-[-50%] w-[198px]">
        <p className="leading-[20px]">Download Aplikasi</p>
      </div>
      <div className="absolute left-[919px] size-[25px] top-[5957px]" data-name="downloads 6">
        <img alt="" className="absolute inset-0 max-w-none object-50%-50% object-cover pointer-events-none size-full" src={imgDownloads5} />
      </div>
      <div className="absolute bg-[#1d2939] h-[53px] left-[1568px] rounded-[30px] top-[5943px] w-[346px]" />
      <div className="absolute flex flex-col font-['Inter:Semi_Bold',sans-serif] font-semibold h-[57px] justify-center leading-[0] left-[1662px] not-italic text-[20px] text-white top-[5969.5px] translate-y-[-50%] w-[198px]">
        <p className="leading-[20px]">Download Aplikasi</p>
      </div>
      <div className="absolute left-[1625px] size-[25px] top-[5957px]" data-name="downloads 7">
        <img alt="" className="absolute inset-0 max-w-none object-50%-50% object-cover pointer-events-none size-full" src={imgDownloads5} />
      </div>
      <div className="absolute flex flex-col font-['Inter:Bold',sans-serif] font-bold h-[44px] justify-center leading-[0] left-[224px] not-italic text-[24px] text-black top-[5462px] translate-y-[-50%] w-[262px]">
        <p className="leading-[24px]">SITS CCTV Surabaya</p>
      </div>
      <div className="absolute flex flex-col font-['Inter:Semi_Bold',sans-serif] font-semibold h-[44px] justify-center leading-[0] left-[959px] not-italic text-[24px] text-black top-[5459px] translate-y-[-50%] w-[262px]">
        <p className="leading-[24px]">KIR Surabaya</p>
      </div>
      <div className="absolute left-[137px] size-[59px] top-[5455px]" data-name="camera 1">
        <img alt="" className="absolute inset-0 max-w-none object-50%-50% object-cover pointer-events-none size-full" src={imgCamera1} />
      </div>
      <div className="absolute left-[227px] size-[16px] top-[5484px]" data-name="star 1">
        <img alt="" className="absolute inset-0 max-w-none object-50%-50% object-cover pointer-events-none size-full" src={imgStar4} />
      </div>
      <div className="absolute flex flex-col font-['Inter:Semi_Bold',sans-serif] font-semibold h-[22px] justify-center leading-[0] left-[248px] not-italic text-[#fec84b] text-[16px] top-[5493px] translate-y-[-50%] w-[27px]">
        <p className="leading-[16px]">4.8</p>
      </div>
      <div className="absolute left-[289px] size-[5px] top-[5489px]">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 5 5">
          <circle cx="2.5" cy="2.5" fill="var(--fill-0, #1D2939)" id="Ellipse 9" r="2.5" />
        </svg>
      </div>
      <div className="absolute flex flex-col font-['Inter:Semi_Bold',sans-serif] font-semibold h-[12px] justify-center leading-[0] left-[299px] not-italic text-[#475467] text-[16px] top-[5492px] translate-y-[-50%] w-[51px]">
        <p className="leading-[16px]">50K+</p>
      </div>
      <div className="absolute flex flex-col font-['Inter:Semi_Bold',sans-serif] font-semibold h-[44px] justify-center leading-[0] left-[958px] not-italic text-[20px] text-black top-[5800px] translate-y-[-50%] w-[308px]">
        <p className="leading-[20px]">Go-Parkir</p>
      </div>
      <div className="absolute left-[961px] size-[16px] top-[5822px]" data-name="star 5">
        <img alt="" className="absolute inset-0 max-w-none object-50%-50% object-cover pointer-events-none size-full" src={imgStar4} />
      </div>
      <div className="absolute flex flex-col font-['Inter:Semi_Bold',sans-serif] font-semibold h-[22px] justify-center leading-[0] left-[982px] not-italic text-[#fec84b] text-[16px] top-[5831px] translate-y-[-50%] w-[27px]">
        <p className="leading-[16px]">4.8</p>
      </div>
      <div className="absolute left-[1023px] size-[5px] top-[5827px]">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 5 5">
          <circle cx="2.5" cy="2.5" fill="var(--fill-0, #1D2939)" id="Ellipse 9" r="2.5" />
        </svg>
      </div>
      <div className="absolute flex flex-col font-['Inter:Semi_Bold',sans-serif] font-semibold h-[12px] justify-center leading-[0] left-[1033px] not-italic text-[#475467] text-[16px] top-[5830px] translate-y-[-50%] w-[51px]">
        <p className="leading-[16px]">40K+</p>
      </div>
      <div className="absolute flex flex-col font-['Inter:Semi_Bold',sans-serif] font-semibold h-[44px] justify-center leading-[0] left-[1663px] not-italic text-[20px] text-black top-[5800px] translate-y-[-50%] w-[308px]">
        <p className="leading-[20px]">GOBIS Suroboyo Bus</p>
      </div>
      <div className="absolute left-[1666px] size-[16px] top-[5822px]" data-name="star 6">
        <img alt="" className="absolute inset-0 max-w-none object-50%-50% object-cover pointer-events-none size-full" src={imgStar4} />
      </div>
      <div className="absolute flex flex-col font-['Inter:Semi_Bold',sans-serif] font-semibold h-[22px] justify-center leading-[0] left-[1687px] not-italic text-[#fec84b] text-[16px] top-[5831px] translate-y-[-50%] w-[27px]">
        <p className="leading-[16px]">4.9</p>
      </div>
      <div className="absolute left-[1728px] size-[5px] top-[5827px]">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 5 5">
          <circle cx="2.5" cy="2.5" fill="var(--fill-0, #1D2939)" id="Ellipse 9" r="2.5" />
        </svg>
      </div>
      <div className="absolute flex flex-col font-['Inter:Semi_Bold',sans-serif] font-semibold h-[12px] justify-center leading-[0] left-[1738px] not-italic text-[#475467] text-[16px] top-[5830px] translate-y-[-50%] w-[51px]">
        <p className="leading-[16px]">90K+</p>
      </div>
      <div className="absolute left-[967px] size-[16px] top-[5483px]" data-name="star 2">
        <img alt="" className="absolute inset-0 max-w-none object-50%-50% object-cover pointer-events-none size-full" src={imgStar4} />
      </div>
      <div className="absolute flex flex-col font-['Inter:Semi_Bold',sans-serif] font-semibold h-[22px] justify-center leading-[0] left-[988px] not-italic text-[#fec84b] text-[16px] top-[5492px] translate-y-[-50%] w-[27px]">
        <p className="leading-[16px]">4.7</p>
      </div>
      <div className="absolute left-[1029px] size-[5px] top-[5488px]">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 5 5">
          <circle cx="2.5" cy="2.5" fill="var(--fill-0, #1D2939)" id="Ellipse 9" r="2.5" />
        </svg>
      </div>
      <div className="absolute flex flex-col font-['Inter:Semi_Bold',sans-serif] font-semibold h-[12px] justify-center leading-[0] left-[1039px] not-italic text-[#475467] text-[16px] top-[5491px] translate-y-[-50%] w-[51px]">
        <p className="leading-[16px]">50K+</p>
      </div>
      <div className="absolute flex flex-col font-['Inter:Semi_Bold',sans-serif] font-semibold h-[44px] justify-center leading-[0] left-[1664px] not-italic text-[24px] text-black top-[5459px] translate-y-[-50%] w-[262px]">
        <p className="leading-[24px]">Transportasiku</p>
      </div>
      <div className="absolute left-[1672px] size-[16px] top-[5483px]" data-name="star 3">
        <img alt="" className="absolute inset-0 max-w-none object-50%-50% object-cover pointer-events-none size-full" src={imgStar4} />
      </div>
      <div className="absolute flex flex-col font-['Inter:Semi_Bold',sans-serif] font-semibold h-[22px] justify-center leading-[0] left-[1693px] not-italic text-[#fec84b] text-[16px] top-[5492px] translate-y-[-50%] w-[27px]">
        <p className="leading-[16px]">4.9</p>
      </div>
      <div className="absolute left-[1734px] size-[5px] top-[5488px]">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 5 5">
          <circle cx="2.5" cy="2.5" fill="var(--fill-0, #1D2939)" id="Ellipse 9" r="2.5" />
        </svg>
      </div>
      <div className="absolute flex flex-col font-['Inter:Semi_Bold',sans-serif] font-semibold h-[12px] justify-center leading-[0] left-[1744px] not-italic text-[#475467] text-[16px] top-[5491px] translate-y-[-50%] w-[51px]">
        <p className="leading-[16px]">100K+</p>
      </div>
      <div className="absolute flex flex-col font-['Inter:Medium',sans-serif] font-medium h-[42px] justify-center leading-[0] left-[122px] not-italic text-[#475467] text-[20px] top-[5566px] translate-y-[-50%] w-[359px]">
        <p className="leading-[20px]">Monitoring CCTV Kota Surabaya</p>
      </div>
      <div className="absolute flex flex-col font-['Inter:Medium',sans-serif] font-medium h-[42px] justify-center leading-[20px] left-[856px] not-italic text-[#475467] text-[20px] top-[5922px] translate-y-[-50%] w-[399px]">
        <p className="mb-0">Sistem parkir digital</p>
        <p>&nbsp;</p>
      </div>
      <div className="absolute flex flex-col font-['Inter:Medium',sans-serif] font-medium h-[42px] justify-center leading-[20px] left-[1561px] not-italic text-[#475467] text-[20px] top-[5928px] translate-y-[-50%] w-[399px]">
        <p className="mb-0">Informasi dan pemesanan bus kota</p>
        <p>&nbsp;</p>
      </div>
      <div className="absolute flex flex-col font-['Inter:Medium',sans-serif] font-medium justify-center leading-[0] left-[857px] not-italic text-[#475467] text-[20px] top-[5562px] translate-y-[-50%] w-[392px]">
        <p className="leading-[20px]">KIR Monitoring DISHUB Kota Surabaya</p>
      </div>
      <div className="absolute flex flex-col font-['Inter:Medium',sans-serif] font-medium justify-center leading-[18px] left-[1562px] not-italic text-[#475467] text-[18px] top-[5576px] translate-y-[-50%] w-[466px]">
        <p className="mb-0">Info transportasi umum dan fasilitas kota</p>
        <p>&nbsp;</p>
      </div>
      <div className="absolute left-[873px] size-[57px] top-[5456px]" data-name="checkmark (1) 1">
        <img alt="" className="absolute inset-0 max-w-none object-50%-50% object-cover pointer-events-none size-full" src={imgCheckmark11} />
      </div>
      <Group />
      <div className="absolute h-[60px] left-[876px] top-[5797px] w-[50px]" data-name="image 4">
        <img alt="" className="absolute inset-0 max-w-none object-50%-50% object-cover pointer-events-none size-full" src={imgImage4} />
      </div>
      <div className="absolute left-[1573px] size-[65px] top-[5794px]" data-name="Logo SB-1 1">
        <img alt="" className="absolute inset-0 max-w-none object-50%-50% object-cover pointer-events-none size-full" src={imgLogoSb11} />
      </div>
      <div className="absolute h-0 left-[978px] top-[5201px] w-[116px]">
        <div className="absolute bottom-0 left-0 right-0 top-[-8px]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 116 8">
            <line id="Line 31" stroke="var(--stroke-0, #F79009)" strokeLinecap="round" strokeWidth="8" x1="4" x2="112" y1="4" y2="4" />
          </svg>
        </div>
      </div>
      <div className="absolute h-[66px] left-[189px] top-[3361px] w-[45px]" data-name="SUV">
        <img alt="" className="absolute inset-0 max-w-none object-50%-50% object-contain pointer-events-none size-full" src={imgSuv} />
      </div>
      <div className="absolute left-[-437px] size-0 top-[1745px]" data-name="30">
        <img alt="" className="absolute inset-0 max-w-none object-50%-50% object-cover pointer-events-none size-full" src={img31} />
      </div>
      <div className="absolute flex flex-col font-['Inter:Bold',sans-serif] font-bold h-[87px] justify-center leading-[0] left-[797px] not-italic text-[#2c5e8f] text-[48px] top-[5256.5px] translate-y-[-50%] w-[478px]">
        <p className="leading-[60px]">APLIKASI MOBILE</p>
      </div>
      <div className="absolute flex flex-col font-['Inter:Medium',sans-serif] font-medium h-[85px] justify-center leading-[0] left-[714px] not-italic text-[#475467] text-[20px] top-[5316.5px] translate-y-[-50%] w-[644px]">
        <p className="leading-[20px]">Download aplikasi untuk pengalaman layanan yang lebih baik</p>
      </div>
      <div className="absolute left-[2203px] size-0 top-[6235px]" data-name="Logo_of_the_Ministry_of_Transportation_of_the_Republic_of_Indonesia.svg 2">
        <img alt="" className="absolute inset-0 max-w-none object-50%-50% object-cover pointer-events-none size-full" src={imgLogoOfTheMinistryOfTransportationOfTheRepublicOfIndonesiaSvg3} />
      </div>
      <div className="absolute bg-white h-[300px] left-[94px] rounded-[30px] shadow-[-15px_18px_20px_0px_rgba(0,0,0,0.3)] top-[6443px] w-[1856px]" />
      <div className="absolute h-0 left-[197px] top-[6593px] w-[1649px]">
        <div className="absolute bottom-0 left-0 right-0 top-[-2px]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 1649 2">
            <line id="Line 33" stroke="var(--stroke-0, #D0D5DD)" strokeWidth="2" x2="1649" y1="1" y2="1" />
          </svg>
        </div>
      </div>
      <div className="absolute bg-gradient-to-r border border-[#eaecf0] border-solid from-[#f4f4f4] h-[60px] left-[187px] rounded-[20px] to-[#e0e0e0] top-[6477px] w-[213px]" />
      <div className="absolute flex flex-col font-['Inter:Medium',sans-serif] font-medium h-[54px] justify-center leading-[0] left-[203px] not-italic text-[20px] text-black top-[6507px] translate-y-[-50%] w-[139px]">
        <p className="leading-[20px]">Kramat Djati</p>
      </div>
      <div className="absolute bg-[#f79009] h-[26px] left-[329px] rounded-[30px] top-[6467px] w-[82px]" />
      <div className="absolute flex flex-col font-['Inter:Semi_Bold',sans-serif] font-semibold h-[29px] justify-center leading-[0] left-[351px] not-italic text-[14px] text-white top-[6479.5px] translate-y-[-50%] w-[85px]">
        <p className="leading-[14px]">Popular</p>
      </div>
      <div className="absolute left-[334px] size-[15px] top-[6473px]" data-name="rise 2">
        <img alt="" className="absolute inset-0 max-w-none object-50%-50% object-cover pointer-events-none size-full" src={imgRise1} />
      </div>
      <div className="absolute left-[351px] size-[20px] top-[6497px]" data-name="share 1">
        <img alt="" className="absolute inset-0 max-w-none object-50%-50% object-cover pointer-events-none size-full" src={imgShare1} />
      </div>
      <div className="absolute bg-gradient-to-r border border-[#eaecf0] border-solid from-[#f4f4f4] h-[60px] left-[431px] rounded-[20px] to-[#e0e0e0] top-[6477px] w-[227px]" />
      <div className="absolute flex flex-col font-['Inter:Medium',sans-serif] font-medium h-[54px] justify-center leading-[0] left-[447px] not-italic text-[20px] text-black top-[6507px] translate-y-[-50%] w-[153px]">
        <p className="leading-[20px]">Gunung Harta</p>
      </div>
      <div className="absolute bg-[#f79009] h-[26px] left-[587px] rounded-[30px] top-[6467px] w-[82px]" />
      <div className="absolute flex flex-col font-['Inter:Semi_Bold',sans-serif] font-semibold h-[29px] justify-center leading-[0] left-[609px] not-italic text-[14px] text-white top-[6479.5px] translate-y-[-50%] w-[85px]">
        <p className="leading-[14px]">Popular</p>
      </div>
      <div className="absolute left-[592px] size-[15px] top-[6473px]" data-name="rise 3">
        <img alt="" className="absolute inset-0 max-w-none object-50%-50% object-cover pointer-events-none size-full" src={imgRise1} />
      </div>
      <div className="absolute left-[609px] size-[20px] top-[6497px]" data-name="share 2">
        <img alt="" className="absolute inset-0 max-w-none object-50%-50% object-cover pointer-events-none size-full" src={imgShare1} />
      </div>
      <div className="absolute bg-gradient-to-r border border-[#eaecf0] border-solid from-[#f4f4f4] h-[60px] left-[689px] rounded-[20px] to-[#e0e0e0] top-[6479px] w-[256px]" />
      <div className="absolute flex flex-col font-['Inter:Medium',sans-serif] font-medium h-[54px] justify-center leading-[0] left-[703px] not-italic text-[20px] text-black top-[6509px] translate-y-[-50%] w-[184px]">
        <p className="leading-[20px]">Garuda Indonesia</p>
      </div>
      <div className="absolute bg-[#f79009] h-[26px] left-[874px] rounded-[30px] top-[6469px] w-[82px]" />
      <div className="absolute flex flex-col font-['Inter:Semi_Bold',sans-serif] font-semibold h-[29px] justify-center leading-[0] left-[896px] not-italic text-[#fcfcfd] text-[14px] top-[6481.5px] translate-y-[-50%] w-[85px]">
        <p className="leading-[14px]">Popular</p>
      </div>
      <div className="absolute left-[879px] size-[15px] top-[6475px]" data-name="rise 4">
        <img alt="" className="absolute inset-0 max-w-none object-50%-50% object-cover pointer-events-none size-full" src={imgRise1} />
      </div>
      <div className="absolute left-[896px] size-[20px] top-[6499px]" data-name="share 3">
        <img alt="" className="absolute inset-0 max-w-none object-50%-50% object-cover pointer-events-none size-full" src={imgShare1} />
      </div>
      <div className="absolute bg-gradient-to-r border border-[#eaecf0] border-solid from-[#f4f4f4] h-[60px] left-[983px] rounded-[20px] to-[#e0e0e0] top-[6479px] w-[150px]" />
      <div className="absolute flex flex-col font-['Inter:Medium',sans-serif] font-medium h-[54px] justify-center leading-[0] left-[995px] not-italic text-[20px] text-black top-[6509px] translate-y-[-50%] w-[80px]">
        <p className="leading-[20px]">Ayo Bis</p>
      </div>
      <div className="absolute bg-[#f79009] h-[26px] left-[1062px] rounded-[30px] top-[6469px] w-[82px]" />
      <div className="absolute flex flex-col font-['Inter:Semi_Bold',sans-serif] font-semibold h-[29px] justify-center leading-[0] left-[1084px] not-italic text-[14px] text-white top-[6481.5px] translate-y-[-50%] w-[85px]">
        <p className="leading-[14px]">Popular</p>
      </div>
      <div className="absolute left-[1067px] size-[15px] top-[6475px]" data-name="rise 5">
        <img alt="" className="absolute inset-0 max-w-none object-50%-50% object-cover pointer-events-none size-full" src={imgRise1} />
      </div>
      <div className="absolute left-[1084px] size-[20px] top-[6499px]" data-name="share 4">
        <img alt="" className="absolute inset-0 max-w-none object-50%-50% object-cover pointer-events-none size-full" src={imgShare1} />
      </div>
      <div className="absolute bg-gradient-to-r border border-[#eaecf0] border-solid from-[#f4f4f4] h-[60px] left-[1169px] rounded-[20px] to-[#e0e0e0] top-[6479px] w-[219px]" />
      <div className="absolute flex flex-col font-['Inter:Medium',sans-serif] font-medium h-[54px] justify-center leading-[0] left-[1186px] not-italic text-[20px] text-black top-[6509px] translate-y-[-50%] w-[117px]">
        <p className="leading-[20px]">Kereta Api</p>
      </div>
      <div className="absolute bg-[#f79009] h-[26px] left-[1284px] rounded-[30px] top-[6469px] w-[120px]" />
      <div className="absolute flex flex-col font-['Inter:Semi_Bold',sans-serif] font-semibold h-[29px] justify-center leading-[0] left-[1316px] not-italic text-[14px] text-white top-[6481.5px] translate-y-[-50%] w-[124px]">
        <p className="leading-[14px]">Popular</p>
      </div>
      <div className="absolute h-[19px] left-[1294px] top-[6473px] w-[18px]" data-name="rise 6">
        <img alt="" className="absolute inset-0 max-w-none object-50%-50% object-cover pointer-events-none size-full" src={imgRise1} />
      </div>
      <div className="absolute h-[24px] left-[1319px] top-[6497px] w-[23px]" data-name="share 5">
        <img alt="" className="absolute inset-0 max-w-none object-50%-50% object-cover pointer-events-none size-full" src={imgShare1} />
      </div>
      <div className="absolute bg-gradient-to-r border border-[#eaecf0] border-solid from-[#f4f4f4] h-[60px] left-[1429px] rounded-[20px] to-[#e0e0e0] top-[6479px] w-[208px]" />
      <div className="absolute flex flex-col font-['Inter:Medium',sans-serif] font-medium h-[54px] justify-center leading-[0] left-[1444px] not-italic text-[20px] text-black top-[6509px] translate-y-[-50%] w-[117px]">
        <p className="leading-[20px]">EasyBook</p>
      </div>
      <div className="absolute bg-[#f79009] h-[26px] left-[1533px] rounded-[30px] top-[6469px] w-[120px]" />
      <div className="absolute flex flex-col font-['Inter:Semi_Bold',sans-serif] font-semibold h-[29px] justify-center leading-[0] left-[1565px] not-italic text-[14px] text-white top-[6481.5px] translate-y-[-50%] w-[124px]">
        <p className="leading-[14px]">Popular</p>
      </div>
      <div className="absolute h-[19px] left-[1543px] top-[6473px] w-[18px]" data-name="rise 7">
        <img alt="" className="absolute inset-0 max-w-none object-50%-50% object-cover pointer-events-none size-full" src={imgRise1} />
      </div>
      <div className="absolute h-[24px] left-[1568px] top-[6497px] w-[23px]" data-name="share 6">
        <img alt="" className="absolute inset-0 max-w-none object-50%-50% object-cover pointer-events-none size-full" src={imgShare1} />
      </div>
      <div className="absolute bg-gradient-to-r border border-[#eaecf0] border-solid from-[#f4f4f4] h-[60px] left-[1678px] rounded-[20px] to-[#e0e0e0] top-[6485px] w-[178px]" />
      <div className="absolute flex flex-col font-['Inter:Medium',sans-serif] font-medium h-[54px] justify-center leading-[0] left-[1695px] not-italic text-[20px] text-black top-[6516px] translate-y-[-50%] w-[117px]">
        <p className="leading-[20px]">Bos Bis</p>
      </div>
      <div className="absolute bg-[#f79009] h-[26px] left-[1752px] rounded-[30px] top-[6475px] w-[120px]" />
      <div className="absolute flex flex-col font-['Inter:Semi_Bold',sans-serif] font-semibold h-[29px] justify-center leading-[0] left-[1784px] not-italic text-[14px] text-white top-[6487.5px] translate-y-[-50%] w-[124px]">
        <p className="leading-[14px]">Popular</p>
      </div>
      <div className="absolute h-[19px] left-[1762px] top-[6479px] w-[18px]" data-name="rise 8">
        <img alt="" className="absolute inset-0 max-w-none object-50%-50% object-cover pointer-events-none size-full" src={imgRise1} />
      </div>
      <div className="absolute h-[24px] left-[1787px] top-[6503px] w-[23px]" data-name="share 7">
        <img alt="" className="absolute inset-0 max-w-none object-50%-50% object-cover pointer-events-none size-full" src={imgShare1} />
      </div>
      <div className="absolute flex flex-col font-['Inter:Medium',sans-serif] font-medium h-[85px] justify-center leading-[0] left-[572px] not-italic text-[#475467] text-[20px] top-[6635.5px] translate-y-[-50%] w-[900px]">
        <p className="leading-[20px]">Dapatkan kemudahan dalam memesan tiket transportasi melalui partner resmi kami</p>
      </div>
      <div className="absolute bg-[#2c5e8f] h-[53px] left-[879px] rounded-[20px] top-[6665px] w-[285px]" />
      <div className="absolute flex flex-col font-['Inter:Semi_Bold',sans-serif] font-semibold h-[135px] justify-center leading-[0] left-[913px] not-italic text-[20px] text-white top-[6690.5px] translate-y-[-50%] w-[217px]">
        <p className="leading-[20px]">Lihat Semua Partner</p>
      </div>
      <div className="absolute bg-gradient-to-r from-[#0aa775] h-[668px] left-[-12px] to-[rgba(10,167,117,0.7)] top-[6824px] w-[2083px]" data-name="Indeks" />
      <div className="absolute h-0 left-[98px] top-[6899px] w-[116px]">
        <div className="absolute bottom-0 left-0 right-0 top-[-8px]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 116 8">
            <line id="Line 31" stroke="var(--stroke-0, #F79009)" strokeLinecap="round" strokeWidth="8" x1="4" x2="112" y1="4" y2="4" />
          </svg>
        </div>
      </div>
      <div className="absolute h-0 left-[98px] top-[6899px] w-[116px]">
        <div className="absolute bottom-0 left-0 right-0 top-[-8px]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 116 8">
            <line id="Line 35" stroke="var(--stroke-0, #FDB022)" strokeLinecap="round" strokeWidth="8" x1="4" x2="112" y1="4" y2="4" />
          </svg>
        </div>
      </div>
      <div className="absolute flex flex-col font-['Inter:Bold',sans-serif] font-bold h-[111px] justify-center leading-[0] left-[98px] not-italic text-[48px] text-white top-[6964.5px] translate-y-[-50%] w-[595px]">
        <p className="leading-[60px]">INDEKS KEPUASAN MASYARAKAT</p>
      </div>
      <div className="absolute flex flex-col font-['Inter:Medium',sans-serif] font-medium h-[85px] justify-center leading-[0] left-[98px] not-italic text-[20px] text-white top-[7062.5px] translate-y-[-50%] w-[801px]">
        <p className="leading-[20px]">Bantu kami meningkatkan kualitas layanan dengan mengisi survei kepuasan masyarakat. Pendapat Anda sangat berarti bagi kami.</p>
      </div>
      <div className="absolute bg-[rgba(134,246,210,0.25)] h-[150px] left-[98px] rounded-[30px] top-[7135px] w-[265px]" />
      <div className="absolute left-[211px] size-[40px] top-[7151px]" data-name="star (1) 1">
        <img alt="" className="absolute inset-0 max-w-none object-50%-50% object-cover pointer-events-none size-full" src={imgStar11} />
      </div>
      <div className="absolute flex flex-col font-['Inter:Bold',sans-serif] font-bold h-[60px] justify-center leading-[0] left-[200px] not-italic text-[36px] text-white top-[7221px] translate-y-[-50%] w-[62px]">
        <p className="leading-[44px]">4.8</p>
      </div>
      <div className="absolute flex flex-col font-['Inter:Medium',sans-serif] font-medium h-[72px] justify-center leading-[0] left-[195px] not-italic text-[#d0d5dd] text-[20px] top-[7260px] translate-y-[-50%] w-[74px]">
        <p className="leading-[20px]">Rating</p>
      </div>
      <div className="absolute bg-[rgba(134,246,210,0.25)] h-[150px] left-[404px] rounded-[30px] top-[7135px] w-[265px]" />
      <div className="absolute flex flex-col font-['Inter:Bold',sans-serif] font-bold h-[60px] justify-center leading-[0] left-[496px] not-italic text-[36px] text-white top-[7221px] translate-y-[-50%] w-[84px]">
        <p className="leading-[44px]">95%</p>
      </div>
      <div className="absolute flex flex-col font-['Inter:Medium',sans-serif] font-medium h-[72px] justify-center leading-[0] left-[509px] not-italic text-[#d0d5dd] text-[20px] top-[7257px] translate-y-[-50%] w-[55px]">
        <p className="leading-[20px]">Puas</p>
      </div>
      <div className="absolute bg-[rgba(134,246,210,0.25)] h-[150px] left-[710px] rounded-[30px] top-[7135px] w-[265px]" />
      <div className="absolute flex flex-col font-['Inter:Bold',sans-serif] font-bold h-[60px] justify-center leading-[0] left-[814px] not-italic text-[36px] text-white top-[7237px] translate-y-[-50%] w-[69px]">
        <p className="leading-[44px]">5K+</p>
      </div>
      <div className="absolute flex flex-col font-['Inter:Medium',sans-serif] font-medium h-[72px] justify-center leading-[0] left-[782px] not-italic text-[#d0d5dd] text-[20px] top-[7257px] translate-y-[-50%] w-[121px]">
        <p className="leading-[20px]">Responden</p>
      </div>
      <div className="absolute left-[518px] size-[39px] top-[7152px]" data-name="rise 9">
        <img alt="" className="absolute inset-0 max-w-none object-50%-50% object-cover pointer-events-none size-full" src={imgRise1} />
      </div>
      <div className="absolute left-[823px] size-[37px] top-[7152px]" data-name="checkmark (2) 1">
        <img alt="" className="absolute inset-0 max-w-none object-50%-50% object-cover pointer-events-none size-full" src={imgCheckmark21} />
      </div>
      <div className="absolute bg-white h-[99px] left-[98px] rounded-[20px] top-[7329px] w-[283px]" />
      <div className="absolute flex flex-col font-['Inter:Bold',sans-serif] font-bold h-[63px] justify-center leading-[0] left-[170px] not-italic text-[#12b76a] text-[30px] top-[7378.5px] translate-y-[-50%] w-[197px]">
        <p className="leading-[30px]">ISI SURVEY</p>
      </div>
      <div className="absolute left-[129px] size-[30px] top-[7364px]" data-name="checkmark (3) 1">
        <img alt="" className="absolute inset-0 max-w-none object-50%-50% object-cover pointer-events-none size-full" src={imgCheckmark31} />
      </div>
      <div className="absolute bg-white h-[468px] left-[1529px] rounded-[30px] top-[6924px] w-[429px]" />
      <div className="absolute bg-gradient-to-t from-[#f3f3f3] left-[1594px] rounded-[30px] size-[300px] to-[rgba(217,255,225,0.3)] top-[6955px]" />
      <div className="absolute left-[1622px] size-[243px] top-[6983px]" data-name="101">
        <img alt="" className="absolute inset-0 max-w-none object-50%-50% object-cover pointer-events-none size-full" src={img101} />
      </div>
      <div className="absolute flex flex-col font-['Inter:Semi_Bold',sans-serif] font-semibold h-[85px] justify-center leading-[0] left-[1744px] not-italic text-[20px] text-black text-center top-[7308.5px] translate-x-[-50%] translate-y-[-50%] w-[242px]">
        <p className="leading-[20px]">
          Scan QR Code untuk
          <br aria-hidden="true" />
          Akses Cepat Survey
        </p>
      </div>
      <div className="absolute bg-gradient-to-r from-[#1e5ca9] h-[558px] left-0 to-[#1e5ca9] top-[7488px] via-[46.155%] via-[rgba(30,92,169,0.8)] w-[2071px]" />
      <div className="absolute h-[154px] left-[98px] top-[7543px] w-[132px]" data-name="Logo_of_the_Ministry_of_Transportation_of_the_Republic_of_Indonesia.svg 4">
        <img alt="" className="absolute inset-0 max-w-none object-50%-50% object-cover pointer-events-none size-full" src={imgLogoOfTheMinistryOfTransportationOfTheRepublicOfIndonesiaSvg3} />
      </div>
      <div className="absolute flex flex-col font-['Inter:Bold',sans-serif] font-bold justify-center leading-[0] left-[251px] not-italic text-[36px] text-nowrap text-white top-[7583px] translate-y-[-50%]">
        <p className="leading-[44px] whitespace-pre">Dinas Perhubungan</p>
      </div>
      <div className="absolute flex flex-col font-['Inter:Bold',sans-serif] font-bold justify-center leading-[0] left-[904px] not-italic text-[36px] text-nowrap text-white top-[7583px] translate-y-[-50%]">
        <p className="leading-[44px] whitespace-pre">Kontak Kami</p>
      </div>
      <div className="absolute flex flex-col font-['Inter:Bold',sans-serif] font-bold justify-center leading-[0] left-[1594px] not-italic text-[36px] text-nowrap text-white top-[7583px] translate-y-[-50%]">
        <p className="leading-[44px] whitespace-pre">Layanan Kami</p>
      </div>
      <div className="absolute flex flex-col font-['Inter:Medium',sans-serif] font-medium h-[39px] justify-center leading-[0] left-[253px] not-italic text-[20px] text-white top-[7624.5px] translate-y-[-50%] w-[160px]">
        <p className="leading-[20px]">Kota Surabaya</p>
      </div>
      <div className="absolute flex flex-col font-['Inter:Medium',sans-serif] font-medium h-[39px] justify-center leading-[0] left-[943px] not-italic text-[18px] text-white top-[7644.5px] translate-y-[-50%] w-[521px]">
        <p className="leading-[18px]">Jl. Taman Jayengrono No.1, Krembangan, Surabaya</p>
      </div>
      <div className="absolute flex flex-col font-['Inter:Medium',sans-serif] font-medium h-[39px] justify-center leading-[0] left-[943px] not-italic text-[18px] text-white top-[7687.5px] translate-y-[-50%] w-[178px]">
        <p className="leading-[18px]">(031) 3520811</p>
      </div>
      <div className="absolute flex flex-col font-['Inter:Medium',sans-serif] font-medium h-[39px] justify-center leading-[0] left-[943px] not-italic text-[18px] text-white top-[7730.5px] translate-y-[-50%] w-[228px]">
        <p className="leading-[18px]">dishub@surabaya.go.id</p>
      </div>
      <div className="absolute flex flex-col font-['Inter:Medium',sans-serif] font-medium h-[85px] justify-center leading-[0] left-[112px] not-italic text-[20px] text-white top-[7749.5px] translate-y-[-50%] w-[598px]">
        <p className="leading-[20px]">Melayani dengan sepenuh hati untuk transportasi yang lebih baik di Kota Surabaya.</p>
      </div>
      <div className="absolute flex flex-col font-['Inter:Medium',sans-serif] font-medium h-[85px] justify-center leading-[20px] left-[112px] not-italic text-[0px] text-[20px] text-white top-[7976.5px] translate-y-[-50%] w-[598px]">
        <p className="mb-0">
          <span>{`©2025 `}</span>
          <a className="cursor-pointer font-['Inter:Medium',sans-serif] font-medium not-italic text-white" href="https://dishub.surabaya.go.id/portal">
            <span className="leading-[20px] text-[20px]" href="https://dishub.surabaya.go.id/portal">
              dishub.surabaya.go.id
            </span>
          </a>
        </p>
        <p>&nbsp;</p>
      </div>
      <div className="absolute flex flex-col font-['Inter:Medium',sans-serif] font-medium h-[85px] justify-center leading-[0] left-[1252px] not-italic text-[20px] text-white top-[7976.5px] translate-y-[-50%] w-[723px]">
        <p className="leading-[20px]">All Rights Reserved. e-Dishub Team Dinas Perhubungan Kota Surabaya</p>
      </div>
      <div className="absolute h-[31px] left-[904px] top-[7629px] w-[30px]" data-name="Place Marker">
        <img alt="" className="absolute inset-0 max-w-none object-50%-50% object-contain pointer-events-none size-full" src={imgPlaceMarker} />
      </div>
      <div className="absolute h-[35px] left-[907px] top-[7670px] w-[24px]" data-name="Phone">
        <img alt="" className="absolute inset-0 max-w-none object-50%-50% object-contain pointer-events-none size-full" src={imgPhone} />
      </div>
      <div className="absolute h-[33px] left-[900px] top-[7714px] w-[38px]" data-name="Gmail Logo">
        <img alt="" className="absolute inset-0 max-w-none object-50%-50% object-contain pointer-events-none size-full" src={imgGmailLogo} />
      </div>
      <div className="absolute flex flex-col font-['Inter:Medium',sans-serif] font-medium h-[252px] justify-center leading-[24px] left-[1594px] not-italic text-[24px] text-white top-[7736px] translate-y-[-50%] w-[381px]">
        <p className="mb-0">→ E-Parkir</p>
        <p className="mb-0">→ E-PKB</p>
        <p className="mb-0">→ E-Terminal</p>
        <p className="mb-0">→ E-Angkutan</p>
        <p className="mb-0">→ KIR Online</p>
        <p>→ CCTV Monitoring</p>
      </div>
      <div className="absolute flex h-[2px] items-center justify-center left-[105px] top-[7919px] w-[1872px]" style={{ "--transform-inner-width": "1872", "--transform-inner-height": "0" } as React.CSSProperties}>
        <div className="flex-none rotate-[359.939deg]">
          <div className="h-0 relative w-[1872px]">
            <div className="absolute bottom-0 left-0 right-0 top-[-2px]" style={{ "--stroke-0": "rgba(190, 190, 190, 1)" } as React.CSSProperties}>
              <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 1872 2">
                <line id="Line 36" stroke="var(--stroke-0, #BEBEBE)" strokeOpacity="0.41" strokeWidth="2" x2="1872" y1="1" y2="1" />
              </svg>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}