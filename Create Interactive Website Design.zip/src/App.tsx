import { useEffect, useRef, useState } from 'react';
import { motion, useInView, useScroll, useTransform } from 'motion/react';
import GeviraRaudatulGaidza from './imports/GeviraRaudatulGaidza';

export default function App() {
  const [activeSlide, setActiveSlide] = useState(0);
  const [isNavSticky, setIsNavSticky] = useState(false);
  const heroRef = useRef(null);
  const { scrollY } = useScroll();
  
  // Parallax effect for hero
  const heroOpacity = useTransform(scrollY, [0, 300], [1, 0.3]);
  const heroScale = useTransform(scrollY, [0, 300], [1, 1.1]);

  // Carousel auto-play
  useEffect(() => {
    const interval = setInterval(() => {
      setActiveSlide((prev) => (prev + 1) % 3);
    }, 5000);
    return () => clearInterval(interval);
  }, []);

  // Sticky navigation
  useEffect(() => {
    const handleScroll = () => {
      setIsNavSticky(window.scrollY > 159);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  // Smooth scroll behavior
  useEffect(() => {
    document.documentElement.style.scrollBehavior = 'smooth';
    return () => {
      document.documentElement.style.scrollBehavior = 'auto';
    };
  }, []);

  return (
    <div className="relative w-full min-h-screen overflow-x-hidden bg-[#f5f5f5]">
      {/* Custom styles for hover effects and animations */}
      <style>{`
        /* Body and html reset */
        body, html {
          margin: 0;
          padding: 0;
          width: 100%;
          overflow-x: hidden;
        }

        /* Main container scaling */
        #scaled-container {
          transform-origin: top center;
          transform: scale(0.7);
          width: 2071px;
          margin: 0 auto;
        }

        /* Smooth transitions for all interactive elements */
        * {
          transition-timing-function: cubic-bezier(0.4, 0, 0.2, 1);
        }

        /* Navigation hover effects */
        .nav-item {
          position: relative;
          transition: all 0.3s ease;
        }
        
        .nav-item:hover {
          transform: translateY(-2px);
          filter: brightness(1.2);
        }
        
        .nav-item::after {
          content: '';
          position: absolute;
          bottom: -8px;
          left: 0;
          right: 0;
          height: 3px;
          background: #F79009;
          transform: scaleX(0);
          transition: transform 0.3s ease;
        }
        
        .nav-item:hover::after {
          transform: scaleX(1);
        }

        /* Button hover effects */
        .btn-primary {
          transition: all 0.3s ease;
          position: relative;
          overflow: hidden;
        }
        
        .btn-primary::before {
          content: '';
          position: absolute;
          top: 50%;
          left: 50%;
          width: 0;
          height: 0;
          border-radius: 50%;
          background: rgba(255, 255, 255, 0.2);
          transform: translate(-50%, -50%);
          transition: width 0.6s, height 0.6s;
        }
        
        .btn-primary:hover::before {
          width: 300px;
          height: 300px;
        }
        
        .btn-primary:hover {
          transform: translateY(-3px);
          box-shadow: 0 10px 25px rgba(0, 0, 0, 0.3);
        }
        
        .btn-primary:active {
          transform: translateY(-1px);
        }

        /* Card hover effects */
        .card-hover {
          transition: all 0.4s cubic-bezier(0.175, 0.885, 0.32, 1.275);
        }
        
        .card-hover:hover {
          transform: translateY(-10px) scale(1.02);
          box-shadow: -20px 25px 35px rgba(0, 0, 0, 0.35);
        }

        /* Link hover effects */
        .link-hover {
          transition: all 0.3s ease;
        }
        
        .link-hover:hover {
          transform: scale(1.05);
          filter: brightness(1.1);
        }

        /* App card hover effects */
        .app-card-hover {
          transition: all 0.3s ease;
        }
        
        .app-card-hover:hover {
          transform: translateY(-8px);
          box-shadow: -5px 10px 30px rgba(0, 0, 0, 0.45);
        }

        /* Social media icon hover */
        .social-icon {
          transition: all 0.3s ease;
        }
        
        .social-icon:hover {
          transform: scale(1.2) rotate(5deg);
        }

        /* Search bar focus effect */
        .search-bar {
          transition: all 0.3s ease;
        }
        
        .search-bar:hover {
          transform: scale(1.02);
          box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
        }

        /* Download button pulse animation */
        @keyframes pulse {
          0%, 100% {
            transform: scale(1);
          }
          50% {
            transform: scale(1.05);
          }
        }
        
        .download-btn {
          transition: all 0.3s ease;
        }
        
        .download-btn:hover {
          animation: pulse 1s infinite;
        }

        /* Provider badge hover */
        .provider-badge {
          transition: all 0.3s ease;
          cursor: pointer;
        }
        
        .provider-badge:hover {
          transform: translateY(-5px);
          box-shadow: 0 8px 20px rgba(247, 144, 9, 0.3);
        }

        /* Smooth scroll */
        html {
          scroll-behavior: smooth;
        }

        /* Chevron button hover */
        .chevron-btn {
          transition: all 0.3s ease;
          cursor: pointer;
        }
        
        .chevron-btn:hover {
          transform: scale(1.15);
          opacity: 1 !important;
        }

        /* Fade in animation */
        .fade-in {
          opacity: 0;
          animation: fadeIn 0.6s ease forwards;
        }
        
        @keyframes fadeIn {
          to {
            opacity: 1;
          }
        }

        /* Slide up animation */
        .slide-up {
          opacity: 0;
          transform: translateY(30px);
          animation: slideUp 0.6s ease forwards;
        }
        
        @keyframes slideUp {
          to {
            opacity: 1;
            transform: translateY(0);
          }
        }

        /* Stats counter animation */
        .stat-item {
          transition: all 0.3s ease;
        }
        
        .stat-item:hover {
          transform: scale(1.1);
        }
      `}</style>

      {/* Enhanced wrapper with scroll animations */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ duration: 0.5 }}
      >
        <div id="scaled-container">
          <EnhancedContent />
        </div>
      </motion.div>
    </div>
  );
}

// Component with enhanced interactions
function EnhancedContent() {
  return (
    <div className="relative">
      {/* Original Figma component with enhanced wrapper */}
      <div id="main-content">
        <GeviraRaudatulGaidza />
      </div>

      {/* Overlay interactive layers */}
      <InteractiveLayers />
    </div>
  );
}

// Interactive overlay components
function InteractiveLayers() {
  return (
    <>
      {/* Navigation items - make them interactive */}
      <div className="absolute left-[156px] top-[191px] w-[1436px] h-[30px] flex gap-[20px] pointer-events-none z-10">
        <NavItem left="0px">BERITA</NavItem>
        <NavItem left="123px">E-ANGKUTAN</NavItem>
        <NavItem left="320px">E-DALOPS</NavItem>
        <NavItem left="480px">E-LALIN</NavItem>
        <NavItem left="613px">E-PARKIR</NavItem>
        <NavItem left="762px">E-PKB</NavItem>
        <NavItem left="878px">E-SARPRAS</NavItem>
        <NavItem left="1044px">E-TERMINAL</NavItem>
        <NavItem left="1226px">PERWALI DISHUB</NavItem>
      </div>

      {/* Hero button */}
      <AnimatedButton
        top="796px"
        left="84px"
        width="260px"
        height="79px"
        className="btn-primary"
      />

      {/* News cards - add hover effects */}
      <NewsCard top="1396px" left="90px" />
      <NewsCard top="1401px" left="761px" />
      <NewsCard top="1401px" left="1432px" />
      <NewsCard top="2050px" left="90px" />
      <NewsCard top="2055px" left="761px" />

      {/* Link cards */}
      <LinkCard top="4818px" left="98px" />
      <LinkCard top="4817px" left="592px" />
      <LinkCard top="4818px" left="1086px" />
      <LinkCard top="4818px" left="1580px" />

      {/* Mobile app cards */}
      <AppCard top="5414px" left="94px" />
      <AppCard top="5414px" left="827px" />
      <AppCard top="5414px" left="1533px" />
      <AppCard top="5756px" left="93px" />
      <AppCard top="5756px" left="826px" />
      <AppCard top="5756px" left="1532px" />

      {/* Social media icons */}
      <SocialIcon top="8px" left="1760px" />
      <SocialIcon top="8px" left="1805px" />
      <SocialIcon top="10px" left="1863px" />
      <SocialIcon top="11px" left="1919px" />
      <SocialIcon top="7px" left="1980px" />

      {/* Search bar */}
      <SearchBar />

      {/* Download buttons */}
      <DownloadButton top="5603px" left="130px" />
      <DownloadButton top="5601px" left="863px" />
      <DownloadButton top="5601px" left="1569px" />
      <DownloadButton top="5943px" left="862px" />
      <DownloadButton top="5943px" left="1568px" />

      {/* Provider badges */}
      <ProviderBadge top="6477px" left="187px" />
      <ProviderBadge top="6477px" left="431px" />
      <ProviderBadge top="6479px" left="689px" />
      <ProviderBadge top="6479px" left="983px" />
      <ProviderBadge top="6479px" left="1169px" />
      <ProviderBadge top="6479px" left="1429px" />
      <ProviderBadge top="6485px" left="1678px" />

      {/* Survey button */}
      <AnimatedButton
        top="7329px"
        left="98px"
        width="283px"
        height="99px"
        className="btn-primary"
      />

      {/* Chevron navigation */}
      <ChevronButton top="662px" left="13px" />
      <ChevronButton top="661px" left="2009px" />
    </>
  );
}

function NavItem({ children, left }: { children: React.ReactNode; left: string }) {
  return (
    <motion.div
      className="absolute nav-item cursor-pointer"
      style={{ left, top: 0 }}
      whileHover={{ scale: 1.05 }}
      whileTap={{ scale: 0.95 }}
    >
      <div className="pointer-events-auto">{children}</div>
    </motion.div>
  );
}

function AnimatedButton({ top, left, width, height, className }: any) {
  return (
    <motion.div
      className={`absolute ${className} cursor-pointer pointer-events-auto`}
      style={{ top, left, width, height }}
      whileHover={{ scale: 1.05 }}
      whileTap={{ scale: 0.95 }}
    />
  );
}

function NewsCard({ top, left }: { top: string; left: string }) {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: "-100px" });

  return (
    <motion.div
      ref={ref}
      className="absolute card-hover cursor-pointer pointer-events-auto"
      style={{ top, left, width: '550px', height: '565px' }}
      initial={{ opacity: 0, y: 50 }}
      animate={isInView ? { opacity: 1, y: 0 } : {}}
      transition={{ duration: 0.6, ease: "easeOut" }}
    />
  );
}

function LinkCard({ top, left }: { top: string; left: string }) {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: "-100px" });

  return (
    <motion.div
      ref={ref}
      className="absolute link-hover cursor-pointer pointer-events-auto"
      style={{ top, left, width: '370px', height: '250px' }}
      initial={{ opacity: 0, scale: 0.9 }}
      animate={isInView ? { opacity: 1, scale: 1 } : {}}
      transition={{ duration: 0.5, ease: "easeOut" }}
    />
  );
}

function AppCard({ top, left }: { top: string; left: string }) {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: "-100px" });

  return (
    <motion.div
      ref={ref}
      className="absolute app-card-hover cursor-pointer pointer-events-auto"
      style={{ top, left, width: '417px', height: '269px' }}
      initial={{ opacity: 0, y: 30 }}
      animate={isInView ? { opacity: 1, y: 0 } : {}}
      transition={{ duration: 0.6, ease: "easeOut" }}
    />
  );
}

function SocialIcon({ top, left }: { top: string; left: string }) {
  return (
    <motion.div
      className="absolute social-icon cursor-pointer pointer-events-auto"
      style={{ top, left, width: '32px', height: '32px' }}
      whileHover={{ scale: 1.2, rotate: 5 }}
      whileTap={{ scale: 0.9 }}
    />
  );
}

function SearchBar() {
  return (
    <motion.div
      className="absolute search-bar cursor-pointer pointer-events-auto"
      style={{ top: '73px', left: '1448px', width: '312px', height: '58px' }}
      whileHover={{ scale: 1.02 }}
      whileFocus={{ scale: 1.02 }}
    />
  );
}

function DownloadButton({ top, left }: { top: string; left: string }) {
  return (
    <motion.div
      className="absolute download-btn cursor-pointer pointer-events-auto"
      style={{ top, left, width: '346px', height: '53px' }}
      whileHover={{ scale: 1.05 }}
      whileTap={{ scale: 0.95 }}
    />
  );
}

function ProviderBadge({ top, left }: { top: string; left: string }) {
  return (
    <motion.div
      className="absolute provider-badge pointer-events-auto"
      style={{ top, left, width: '213px', height: '60px' }}
      whileHover={{ y: -5 }}
      whileTap={{ scale: 0.98 }}
    />
  );
}

function ChevronButton({ top, left }: { top: string; left: string }) {
  return (
    <motion.div
      className="absolute chevron-btn pointer-events-auto"
      style={{ top, left, width: '55px', height: '56px' }}
      whileHover={{ scale: 1.15 }}
      whileTap={{ scale: 0.95 }}
    />
  );
}